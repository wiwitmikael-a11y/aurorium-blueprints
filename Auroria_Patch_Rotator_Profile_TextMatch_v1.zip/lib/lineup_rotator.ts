import fs from 'fs';
import { loadSquadsCsv } from './lineup_lock'; // reuse loader
type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number };

function fitnessOf(state:any, pid:string){ return state?.playerFitness?.[pid]?.fitness ?? 85; }
function isUnavailable(state:any, pid:string){
  const ban = state?.suspensions?.[pid] || 0;
  const inj = state?.injuries?.[pid]?.weeks || 0;
  return (ban>0) || (inj>0);
}

// prefer high OVR but avoid players with fitness <55 when substitutes exist
export function pickXIWithRotator(clubId:string, state:any, squadsPath:string){
  const map = loadSquadsCsv(squadsPath) as Record<string, Player[]>;
  const pool = (map[clubId]||[]).slice().sort((a,b)=> b.ovr-a.ovr);
  const available = pool.filter(p=> !isUnavailable(state,p.player_id));
  const need = { GK:1, DF:4, MF:4, FW:2 };
  const byPos = { GK: available.filter(p=>p.pos==='GK'),
                  DF: available.filter(p=>p.pos==='DF'),
                  MF: available.filter(p=>p.pos==='MF'),
                  FW: available.filter(p=>p.pos==='FW') };
  const xi: Player[] = [];
  const rotatedOut: string[] = [];
  (['GK','DF','MF','FW'] as const).forEach(pos=>{
    let cand = byPos[pos].slice();
    // sort: first those with fitness >=55, then <55
    cand.sort((a,b)=>{
      const fa = fitnessOf(state,a.player_id), fb = fitnessOf(state,b.player_id);
      const ap = (fa<55?1:0), bp=(fb<55?1:0);
      if(ap!==bp) return ap-bp; // prefer fit first
      return b.ovr-a.ovr;
    });
    const chosen = cand.slice(0, need[pos]);
    const lowFit = cand.filter(p=> (state.playerFitness?.[p.player_id]?.fitness??85) < 55).slice(0, Math.max(0, need[pos]-0));
    rotatedOut.push(...lowFit.map(p=>p.player_id));
    xi.push(...chosen);
  });
  // fill if less than 11
  const ids = new Set(xi.map(p=>p.player_id));
  for(const p of available){
    if(xi.length>=11) break;
    if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); }
  }
  // emergency include if still <11
  if(xi.length<11){
    for(const p of pool){
      if(xi.length>=11) break;
      if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); }
    }
  }
  return { xi: xi.slice(0,11), rotatedOut };
}

// rotation recommendations list for UI (players <55 fitness & available)
export function rotationRecommendations(clubId:string, state:any, squadsPath:string){
  const map = loadSquadsCsv(squadsPath) as Record<string, Player[]>;
  const pool = (map[clubId]||[]);
  const recs = [];
  for(const p of pool){
    const fit = fitnessOf(state,p.player_id);
    const avail = !isUnavailable(state,p.player_id);
    if(avail && fit < 55){
      recs.push({ player_id:p.player_id, name:p.name, pos:p.pos, fitness: Math.round(fit) });
    }
  }
  // sort lowest fitness first
  recs.sort((a,b)=> a.fitness-b.fitness);
  return recs;
}
