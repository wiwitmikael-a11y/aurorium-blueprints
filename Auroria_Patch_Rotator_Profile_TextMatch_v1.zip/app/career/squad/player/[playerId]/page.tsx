import Shell from '../../../../../components/Shell';

async function getData(id:string){ 
  const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/player/'+id, { cache:'no-store' });
  return r.json();
}
export default async function Page({ params }:{ params:{ playerId:string }}){
  const data = await getData(params.playerId);
  return (<Shell>
    <h1 className="text-xl mb-2">{data.name} — {data.club}</h1>
    <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
      <div className="panel">
        <h2 className="font-semibold mb-2">Stats</h2>
        <ul className="list-disc pl-5">
          <li>Goals: {data.goals} | Assists: {data.assists} | Clean Sheets: {data.cs}</li>
          <li>Minutes: {data.minutes} | Starts: {data.starts}</li>
          <li>Cards: {data.yc} YC — {data.rc} RC</li>
        </ul>
      </div>
      <div className="panel">
        <h2 className="font-semibold mb-2">Fitness</h2>
        <div>Fitness: <b>{Math.round(data.fitness||85)}</b> — Fatigue: {Math.round(data.fatigue||15)}</div>
        <div>Availability: {data.suspension_left>0?'Suspended '+data.suspension_left+'w': (data.injury_weeks>0?('Injured '+data.injury_weeks+'w'):'OK')}</div>
      </div>
    </div>
    <div className="panel mt-4">
      <h2 className="font-semibold mb-2">Form (last 5)</h2>
      <Sparkline values={data.formLast5||[]} />
    </div>
  </Shell>);
}

function Sparkline({values}:{values:number[]}){
  const w=220, h=60, pad=8;
  const min = Math.min(5, ...values, 10); const max = Math.max(10, ...values, 5);
  const pts = values.map((v,i)=>{
    const x = pad + (i*(w-2*pad))/Math.max(1,(values.length-1));
    const y = h - pad - ((v-min)/(max-min||1))*(h-2*pad);
    return `${x},${y}`;
  }).join(' ');
  return (<svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
    <polyline fill="none" stroke="currentColor" strokeWidth="2" points={pts}/>
    {values.map((v,i)=>{
      const x = pad + (i*(w-2*pad))/Math.max(1,(values.length-1));
      const y = h - pad - ((v-min)/(max-min||1))*(h-2*pad);
      return <circle key={i} cx={x} cy={y} r="3" fill="currentColor"/>;
    })}
    <text x="4" y="12" fontSize="10">5</text>
    <text x="4" y={h-4} fontSize="10">10</text>
  </svg>);
}
