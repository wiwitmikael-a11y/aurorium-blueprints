import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import { rotationRecommendations, pickXIWithRotator } from '../../../../lib/lineup_rotator';

export async function GET(req: Request){
  try{
    const url = new URL(req.url);
    const club = url.searchParams.get('club');
    if(!club) return NextResponse.json({ error:'MISSING_CLUB' }, {status:400});
    const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
    const squadsPath = process.cwd()+'/data/squads.csv';
    const recs = rotationRecommendations(club, state, squadsPath);
    const xi = pickXIWithRotator(club, state, squadsPath);
    return NextResponse.json({ club, recommendations: recs, suggestedXI: xi.xi, rotatedOut: xi.rotatedOut });
  }catch(e:any){
    return NextResponse.json({ error:'ROTATION_ERROR', message:e?.message }, {status:500});
  }
}
