import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';

export async function GET(_:Request, { params }:{ params:{ playerId:string }}){
  try{
    const pid = params.playerId;
    const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
    const ps = state.playerStats?.[pid] || null;
    const fit = state.playerFitness?.[pid] || { fitness:85, fatigue:15 };
    const sus = state.suspensions?.[pid] || 0;
    const inj = state.injuries?.[pid]?.weeks || 0;
    if(!ps) return NextResponse.json({ error:'NOT_FOUND', message:'No player stats yet' }, {status:404});
    return NextResponse.json({
      player_id: pid, name: ps.name, club: ps.club,
      goals: ps.goals, assists: ps.assists, cs: ps.cs, yc: ps.yc, rc: ps.rc,
      minutes: ps.minutes, starts: ps.starts,
      formLast5: ps.formLast5 || [], fitness: fit.fitness, fatigue: fit.fatigue,
      suspension_left: sus, injury_weeks: inj
    });
  }catch(e:any){
    return NextResponse.json({ error:'PLAYER_ERROR', message:e?.message }, {status:500});
  }
}
