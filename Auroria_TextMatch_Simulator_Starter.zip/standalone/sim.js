// Auroria Text Match Simulator (Standalone)
// Simple deterministic engine & UI renderer (client-side only)

const PITCH_W = 12, PITCH_H = 8;
const TICK_MS_BASE = 100; // 10 Hz logic (scaled by speed)
let SPEED = 1;
let PAUSED = false;
let KEY_MOMENTS = false;

const state = {
  clock_s: 0,
  duration_s: 90*60,
  score: {home:0, away:0},
  teams: {home:"AEV", away:"GHV"},
  weather: "NightFog",
  ref: "Strict",
  possession: {team:"home", zone:"C-MidR", pctAEV:0.5},
  ball: {x:6, y:4, owner:null, last:[]},
  intent: {type:"hold", odds:[["short_pass",0.35],["dribble",0.25],["cross",0.2],["shoot",0.2]]},
  tags: [],
  stats: {
    shots:{home:0,away:0}, xg:{home:0,away:0}, passp:{home:0,away:0},
    passes:{home:{succ:0,att:0}, away:{succ:0,att:0}},
    poss_accum:{home:0,away:0}, last_update:0
  },
  roster: {
    home: [
      {num:1,name:"Kael",pos:"GK",race:"Human",elem:"Light",stam:1,mana:0.5,cond:0.98,mor:0.6},
      {num:2,name:"Rurik",pos:"DF",race:"Dwarf",elem:"Earth",stam:0.95,mana:0.2,cond:0.97,mor:0.6},
      {num:3,name:"Brann",pos:"DF",race:"Human",elem:"Earth",stam:0.95,mana:0.2,cond:0.97,mor:0.6},
      {num:4,name:"Elyra",pos:"MF",race:"Elf",elem:"Wind",stam:0.92,mana:0.8,cond:0.98,mor:0.8},
      {num:5,name:"Gorn",pos:"FW",race:"Orc",elem:"Fire",stam:0.90,mana:0.3,cond:0.98,mor:0.7},
      {num:6,name:"Lume",pos:"MF",race:"Human",elem:"Water",stam:0.93,mana:0.6,cond:0.97,mor:0.7},
      {num:7,name:"Fenn",pos:"MF",race:"Human",elem:"Light",stam:0.92,mana:0.4,cond:0.96,mor:0.6},
      {num:8,name:"Drax",pos:"DF",race:"Orc",elem:"Stone",stam:0.96,mana:0.2,cond:0.97,mor:0.5},
      {num:9,name:"Tala",pos:"FW",race:"Elf",elem:"Wind",stam:0.91,mana:0.7,cond:0.98,mor:0.7},
      {num:10,name:"Puck",pos:"FW",race:"Halfling",elem:"Shadow",stam:0.89,mana:0.5,cond:0.98,mor:0.7},
      {num:11,name:"Orr",pos:"DF",race:"Human",elem:"Earth",stam:0.94,mana:0.3,cond:0.97,mor:0.6}
    ],
    away: [
      {num:1,name:"K-12",pos:"GK",race:"Automaton",elem:"Light",stam:1,mana:0.3,cond:0.98,mor:0.6},
      {num:2,name:"Bragg",pos:"DF",race:"Human",elem:"Earth",stam:0.95,mana:0.2,cond:0.97,mor:0.6},
      {num:3,name:"Shade",pos:"DF",race:"Undead",elem:"Shadow",stam:0.93,mana:0.7,cond:0.96,mor:0.6},
      {num:4,name:"Nyra",pos:"MF",race:"Elf",elem:"Water",stam:0.92,mana:0.7,cond:0.97,mor:0.7},
      {num:5,name:"Vex",pos:"MF",race:"Human",elem:"Fire",stam:0.93,mana:0.4,cond:0.96,mor:0.6},
      {num:6,name:"Moro",pos:"MF",race:"Orc",elem:"Stone",stam:0.94,mana:0.2,cond:0.97,mor:0.6},
      {num:7,name:"Zeph",pos:"FW",race:"Elf",elem:"Wind",stam:0.91,mana:0.8,cond:0.98,mor:0.7},
      {num:8,name:"Grim",pos:"FW",race:"Orc",elem:"Fire",stam:0.90,mana:0.6,cond:0.98,mor:0.7},
      {num:9,name:"Rook",pos:"MF",race:"Human",elem:"Light",stam:0.92,mana:0.4,cond:0.97,mor:0.6},
      {num:10,name:"Torr",pos:"DF",race:"Dwarf",elem:"Earth",stam:0.95,mana:0.3,cond:0.97,mor:0.6},
      {num:11,name:"Nox",pos:"MF",race:"Undead",elem:"Shadow",stam:0.92,mana:0.8,cond:0.96,mor:0.6}
    ]
  },
  feed: []
};

function fmtTime(s){
  const m = Math.floor(s/60), ss = Math.floor(s%60);
  return `${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
}

function clamp(v,min,max){ return Math.max(min, Math.min(max,v)); }
function rnd(){ return Math.random(); }

function pickWeighted(opts){
  // opts: [["shoot",0.2],["pass",0.5],["dribble",0.3]]
  let sum = 0; for(const o of opts) sum += o[1];
  let r = rnd()*sum, acc=0;
  for(const o of opts) { acc += o[1]; if(r<=acc) return o[0]; }
  return opts[0][0];
}

function gridZone(x,y){
  const thirdX = (x<4)?"L":(x<8)?"C":"R";
  const bandY = (y<2)?"Top":(y<4)?"Mid":"Deep";
  const mid = (x<6)?"-Def":(x<9)?"-Mid":"-Atk";
  const wing = (y<3||y>4)? "Wide" : "Center";
  return `${thirdX}-${wing}`.replace("--","-");
}

function distanceToGoal(team, x,y){
  // home attacks right (x=11), away attacks left (x=0)
  const gx = (team==="home")? 11 : 0;
  const gy = 4; // center
  const dx = gx - x, dy = gy - y;
  return Math.sqrt(dx*dx + dy*dy);
}

function xgFromDist(dist){
  // simple proxy: closer = higher xG (cap at 0.6)
  const v = Math.max(0, 1 - dist/12);
  return clamp(0.6 * v*v, 0.01, 0.6);
}

// Commentary helpers
function addFeed(text, tags=[]){
  const line = {t: state.clock_s, text, tags};
  state.feed.push(line);
  const feedEl = document.getElementById("feed");
  const div = document.createElement("div");
  div.className = "line";
  div.textContent = `${fmtTime(state.clock_s)} ${text}`;
  feedEl.appendChild(div);
  feedEl.scrollTop = feedEl.scrollHeight;
}

function initUI(){
  // build pitch cells
  const pitch = document.getElementById("pitch");
  pitch.innerHTML = "";
  for(let y=0;y<PITCH_H;y++){
    for(let x=0;x<PITCH_W;x++){
      const cell = document.createElement("div");
      cell.className = "zone";
      cell.dataset.x = x; cell.dataset.y = y;
      pitch.appendChild(cell);
    }
  }
  renderTeams();
}

function renderTeams(){
  function tableFor(side, elId){
    const tbl = document.getElementById(elId);
    const rows = [`<tr><th>#</th><th>Nama</th><th>Pos</th><th>STAM</th><th>MANA</th><th>COND</th></tr>`];
    for(const p of state.roster[side]){
      const pip = (v)=>{
        const n = Math.round(v*10);
        return `<span class="pip">${"█".repeat(n)}${"░".repeat(10-n)}</span>`;
      };
      rows.push(`<tr><td>${p.num}</td><td>${p.name}</td><td>${p.pos}</td><td>${pip(p.stam)}</td><td>${pip(p.mana)}</td><td>${Math.round(p.cond*100)}%</td></tr>`);
    }
    tbl.innerHTML = rows.join("");
  }
  tableFor("home","teamA");
  tableFor("away","teamB");
}

function renderUI(){
  document.getElementById("score").textContent = `${state.teams.home} ${state.score.home}–${state.score.away} ${state.teams.away}`;
  document.getElementById("clock").textContent = fmtTime(state.clock_s);
  document.getElementById("weather").textContent = state.weather;
  document.getElementById("ref").textContent = state.ref;
  document.getElementById("posTeam").textContent = state.possession.team==="home"? state.teams.home : state.teams.away;
  document.getElementById("posZone").textContent = state.possession.zone;
  document.getElementById("posAEV").textContent = Math.round(state.possession.pctAEV*100)+"%";
  document.getElementById("shots").textContent = `${state.stats.shots.home}–${state.stats.shots.away}`;
  document.getElementById("xg").textContent = `${state.stats.xg.home.toFixed(2)}–${state.stats.xg.away.toFixed(2)}`;
  document.getElementById("passp").textContent = `${calcPassPct("home")}–${calcPassPct("away")}`;
  // tags
  document.getElementById("tags").textContent = state.tags.join(" ");
  // odds
  const act = document.getElementById("actions");
  act.innerHTML = state.intent.odds.map(o=>{
    const pct = Math.round(o[1]*100);
    return `<div>${o[0]} — <b>${pct}%</b></div>`;
  }).join("");

  // pitch
  for(const cell of document.querySelectorAll("#pitch .zone")) cell.innerHTML = "";
  const idx = (x,y)=>document.querySelector(`#pitch .zone[data-x="${x}"][data-y="${y}"]`);
  for(const p of state.ball.last){
    const c = idx(p[0],p[1]); if(!c) continue;
    const lp = document.createElement("div");
    lp.className = "lastpath";
    c.appendChild(lp);
  }
  const cell = idx(state.ball.x, state.ball.y);
  if(cell){
    const b = document.createElement("div"); b.className="ball"; cell.appendChild(b);
    const o = document.createElement("div"); o.className="owner"; cell.appendChild(o);
  }
}

function calcPassPct(side){
  const p = state.stats.passes[side];
  const pct = p.att>0 ? Math.round(100*p.succ/p.att) : 0;
  return pct+"%";
}

function updatePossession(dt){
  // naive possession: integrate time by team
  if(state.possession.team==="home") state.stats.poss_accum.home += dt;
  else state.stats.poss_accum.away += dt;
  const total = state.stats.poss_accum.home + state.stats.poss_accum.away + 1e-6;
  state.possession.pctAEV = state.stats.poss_accum.home/total;
}

function chooseIntent(){
  // Base odds by zone
  const x = state.ball.x, y = state.ball.y;
  const zone = gridZone(x,y);
  const team = state.possession.team;
  let odds = [["short_pass",0.35],["dribble",0.25],["cross",0.15],["shoot",0.15],["hold",0.1]];
  if((team==="home" && x>=9) || (team==="away" && x<=2)){ // in final third
    odds = [["shoot",0.32],["short_pass",0.25],["cross",0.25],["dribble",0.12],["hold",0.06]];
  }
  // Synergy tag example: Fire+Wind in attack → buff cross
  state.tags = [];
  const haveFireWind = (team==="home")
    ? state.roster.home.some(p=>p.elem==="Wind") && state.roster.home.some(p=>p.elem==="Fire")
    : state.roster.away.some(p=>p.elem==="Wind") && state.roster.away.some(p=>p.elem==="Fire");
  if(haveFireWind && ((team==="home"&&x>=8)||(team==="away"&&x<=3))){
    state.tags.push("Synergy: Gale");
    odds = odds.map(([k,v])=> k==="cross" ? [k, v*1.25] : [k, v]);
  }
  // Weather NightFog → slightly less shoot
  if(state.weather==="NightFog"){
    odds = odds.map(([k,v])=> k==="shoot" ? [k, v*0.9] : [k, v]);
  }
  // normalize
  const sum = odds.reduce((a,b)=>a+b[1],0);
  odds = odds.map(([k,v])=>[k, v/sum]);
  state.intent = {type: pickWeighted(odds), odds};
}

function advanceBall(){
  const team = state.possession.team;
  // move ball by intent
  let nx = state.ball.x, ny = state.ball.y;
  let text = "", tags=[];
  const dir = (team==="home") ? 1 : -1;
  if(state.intent.type==="short_pass"){
    state.stats.passes[team].att++;
    nx += dir * (Math.random()<0.7?1:2);
    ny += (Math.random()<0.5?0:(Math.random()<0.5?1:-1));
    const succ = Math.random()<0.82;
    if(!succ){ // interception
      addFeed(`${team==="home"?"GHV":"AEV"} memotong umpan!`,["intercept"]);
      state.possession.team = (team==="home"?"away":"home");
      state.ball.last = [[state.ball.x,state.ball.y]];
      return;
    }else{
      state.stats.passes[team].succ++;
      text = "Umpan pendek berhasil.";
    }
  } else if(state.intent.type==="dribble"){
    nx += dir * 1; ny += (Math.random()<0.5?0:(Math.random()<0.5?1:-1));
    text = "Dribble melewati tekanan.";
    if(Math.random()<0.22){ addFeed("Ditekel! Pelanggaran ringan.",["foul"]); /* keep possession */ }
  } else if(state.intent.type==="cross"){
    nx += dir * 2; ny += (ny<4?1:-1);
    text = state.tags.includes("Synergy: Gale") ? "Gale Cross—umpan melengkung tajam!" : "Umpan silang ke kotak!";
  } else if(state.intent.type==="shoot"){
    const dist = distanceToGoal(team, state.ball.x, state.ball.y);
    let xg = xgFromDist(dist);
    if(state.tags.includes("Synergy: Gale")) xg *= 1.1;
    const goal = Math.random() < xg;
    const side = team==="home" ? "AEV" : "GHV";
    state.stats.shots[team]++; state.stats.xg[team] += xg;
    addFeed(`${side} menembak! xG ${xg.toFixed(2)} ${goal?"— GOL!":"— diselamatkan."}`,["shot", goal?"goal":"save"]);
    if(goal){
      if(team==="home") state.score.home++; else state.score.away++;
      // reset to center
      state.ball.last = [[state.ball.x,state.ball.y]];
      state.ball.x = PITCH_W/2|0; state.ball.y = PITCH_H/2|0;
      state.possession.team = (team==="home"?"away":"home");
      return;
    } else {
      // keeper holds or corner; simplify: keeper holds
      state.possession.team = (team==="home"?"away":"home");
      state.ball.last = [[state.ball.x,state.ball.y]];
      return;
    }
  } else {
    text = "Menahan bola, mencari opsi.";
  }
  nx = clamp(nx,0,PITCH_W-1); ny = clamp(ny,0,PITCH_H-1);
  state.ball.last = [[state.ball.x,state.ball.y]];
  state.ball.x = nx; state.ball.y = ny;
  addFeed(text, [state.intent.type]);
}

function tick(dt){
  state.clock_s = Math.min(state.clock_s + dt, state.duration_s);
  updatePossession(dt);
  chooseIntent();
  advanceBall();
}

function loop(){
  if(!PAUSED){
    const dt = (TICK_MS_BASE/1000) * SPEED;
    tick(dt);
    renderUI();
  }
  const interval = TICK_MS_BASE / SPEED;
  setTimeout(loop, interval);
}

// Controls
function setSpeed(s){ SPEED = s; }
function togglePause(){ PAUSED = !PAUSED; document.getElementById("pauseBtn").textContent = PAUSED?"Resume":"Pause"; }
function toggleKey(){ KEY_MOMENTS = !KEY_MOMENTS; addFeed(KEY_MOMENTS?"Mode Key Moments ON":"Mode Key Moments OFF"); }
function shout(type){ addFeed("Instruksi manajer: "+type); }

// Boot
initUI();
renderUI();
addFeed("Kickoff! Cuaca NightFog, wasit Strict.");
setTimeout(loop, 250);
