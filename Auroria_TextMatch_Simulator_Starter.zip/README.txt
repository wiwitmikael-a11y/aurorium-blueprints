# Auroria Text Match — Starter

Dua opsi:
1) **Standalone**: buka `standalone/index.html` di browser → simulasi jalan (text-based + mini pitch).
2) **Next.js Snippets**: folder `next-app-snippets/` berisi komponen React (MiniPitch, ActionBox, Commentary, Stats) siap dipasang ke proyek Next.js (Vercel).

## Jalankan Standalone
- Cukup buka file: `standalone/index.html`

## Integrasi Next.js
- Salin `components/` ke proyek Next (app router).
- Buat page `/app/match/page.tsx` yang memanggil engine client-side (mirip `standalone/sim.js` di-port ke TS).
- Styling: copy CSS sederhana dari `standalone/index.html` ke global.css dan adapt.

## Next Steps
- Sambungkan ke YAML configs (spells/synergy) → render tag di ActionBox dan variasi grammar komentar.
- Implement `Key Moments` filter di feed.
- Tambah panel `Team Sheets` (stamina/mana) ke snippets.

