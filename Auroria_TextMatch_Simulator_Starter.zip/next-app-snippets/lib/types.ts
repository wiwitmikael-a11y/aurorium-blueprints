export type TeamSide = 'home'|'away';
export interface Score { home:number; away:number; }
export interface Ball { x:number; y:number; last:number[][]; owner?:string|null; }
export interface Intent { type:string; odds:[string,number][]; }
export interface LiveState {
  clock_s:number;
  duration_s:number;
  score:Score;
  teams:{home:string; away:string};
  weather:string;
  ref:string;
  possession:{team:TeamSide; zone:string; pctAEV:number};
  ball:Ball;
  intent:Intent;
  tags:string[];
  stats:{
    shots:Score; xg:Score; passes:{home:{succ:number,att:number}, away:{succ:number,att:number}};
    poss_accum:{home:number,away:number};
  };
}
