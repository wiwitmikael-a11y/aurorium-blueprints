'use client';
import React from 'react';

export function ActionBox({team,zone,intent,tags}:{team:string;zone:string;intent:{odds:[string,number][]};tags:string[]}){
  return (
    <div className="card">
      <div className="title">Action Box</div>
      <div>Possession: <b>{team}</b> • Zone: <b>{zone}</b> {tags.length>0 && <span className="badge">{tags.join(' ')}</span>}</div>
      <div className="actions">
        {intent.odds.map(([k,v])=> <div key={k}>{k} — <b>{Math.round(v*100)}%</b></div>)}
      </div>
    </div>
  );
}
