'use client';
import React from 'react';

export function MiniPitchGrid({ball}:{ball:{x:number,y:number,last:number[][]}}){
  const cells = [];
  for(let y=0;y<8;y++){
    for(let x=0;x<12;x++){
      const key = x+'_'+y;
      const hasBall = ball.x===x && ball.y===y;
      const last = ball.last.some(p=>p[0]===x&&p[1]===y);
      cells.push(
        <div key={key} className="zone">
          {last && <div className="lastpath"/>}
          {hasBall && <><div className="ball"/><div className="owner"/></>}
        </div>
      );
    }
  }
  return <div id="pitch" className="pitch">{cells}</div>;
}
