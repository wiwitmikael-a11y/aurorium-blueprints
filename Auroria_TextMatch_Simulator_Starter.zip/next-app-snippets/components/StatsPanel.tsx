'use client';
import React from 'react';

export function StatsPanel({posAEV,shots,xg,passp}:{posAEV:number;shots:[number,number];xg:[number,number];passp:[number,number]}){
  return (
    <div className="card">
      <div className="title">Match Stats</div>
      <div className="stats">
        <div>Possession AEV: {Math.round(posAEV*100)}%</div>
        <div>Shots: {shots[0]}–{shots[1]}</div>
        <div>xG: {xg[0].toFixed(2)}–{xg[1].toFixed(2)}</div>
        <div>Pass%: {passp[0]}–{passp[1]}</div>
      </div>
    </div>
  );
}
