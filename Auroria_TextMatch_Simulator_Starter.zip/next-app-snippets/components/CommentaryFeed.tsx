'use client';
import React from 'react';

export function CommentaryFeed({lines}:{lines:{t:number;text:string}[]}){
  return (
    <div className="card">
      <div className="title">Live Commentary</div>
      <div className="feed">
        {lines.map((l,i)=>(<div key={i} className="line">{fmt(l.t)} {l.text}</div>))}
      </div>
    </div>
  );
}
function fmt(s:number){ const m = Math.floor(s/60), ss = Math.floor(s%60); return `${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}` }
