import { loadSquadsCsv } from './lineup_lock';
type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number };
type PlayerStats = { formLast5:number[] };

function avg(arr:number[]){ return arr.length? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }
function isUnavailable(state:any, pid:string){
  const ban = state?.suspensions?.[pid] || 0;
  const inj = state?.injuries?.[pid]?.weeks || 0;
  return (ban>0) || (inj>0);
}
function fitnessOf(state:any, pid:string){ return state?.playerFitness?.[pid]?.fitness ?? 85; }
function formAvgOf(state:any, pid:string){ const ps = state?.playerStats?.[pid] as PlayerStats|undefined; return ps ? avg(ps.formLast5||[]) : 0; }

// determine congestion: matches in next 7 days (week granularity → check multiple fixtures same week or double headers via flag)
function isCongested(state:any): boolean{
  // heuristic: if there are >10 fixtures scheduled for the same club in a calendar week system is not available here.
  // fallback: if league config marks 'midweek=true' in this week in state, but we don't have it. Use random/false.
  // More simply: if total fixtures for this week > (teams/2), still considered single round. We'll allow opt-in via state.meta.congestedWeek
  return Boolean(state?.meta?.congestedWeek);
}

export function pickXIWithRotatorPro(clubId:string, state:any, squadsPath:string){
  const map = loadSquadsCsv(squadsPath) as Record<string, Player[]>;
  const pool = (map[clubId]||[]).slice().sort((a,b)=> b.ovr-a.ovr);
  const available = pool.filter(p=> !isUnavailable(state,p.player_id));
  const need = { GK:1, DF:4, MF:4, FW:2 };
  const byPos = { GK: available.filter(p=>p.pos==='GK'),
                  DF: available.filter(p=>p.pos==='DF'),
                  MF: available.filter(p=>p.pos==='MF'),
                  FW: available.filter(p=>p.pos==='FW') };

  const congested = isCongested(state);
  const baseThresh = 55;
  const thr = congested ? 60 : baseThresh;
  const border = thr - 5; // borderline window

  const xi: Player[] = [];
  const rotatedOut: {player_id:string; fitness:number; form:number}[] = [];
  (['GK','DF','MF','FW'] as const).forEach(pos=>{
    let cand = byPos[pos].slice();
    cand.sort((a,b)=>{
      const fa = fitnessOf(state,a.player_id), fb = fitnessOf(state,b.player_id);
      const aa = formAvgOf(state,a.player_id), ab = formAvgOf(state,b.player_id);
      const aBorder = (fa < thr) && (fa >= border) && (aa >= 7.2);
      const bBorder = (fb < thr) && (fb >= border) && (ab >= 7.2);
      // prefer: fit >= thr; else borderline with good form; else lower fitness
      const aKey = (fa>=thr)?0: (aBorder?1:2);
      const bKey = (fb>=thr)?0: (bBorder?1:2);
      if(aKey!==bKey) return aKey-bKey;
      // tie-break by OVR then form
      if(b.ovr!==a.ovr) return b.ovr-a.ovr;
      return ab-aa;
    });
    const chosen = cand.slice(0, need[pos]);
    xi.push(...chosen);
    // mark players that were skipped due to low fitness
    cand.slice(need[pos]).forEach(p=>{
      const f = fitnessOf(state,p.player_id);
      if(f < thr) rotatedOut.push({player_id:p.player_id, fitness: Math.round(f), form: Number(formAvgOf(state,p.player_id).toFixed(2))});
    });
  });

  // fill to 11 if needed
  const ids = new Set(xi.map(p=>p.player_id));
  for(const p of available){
    if(xi.length>=11) break;
    if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); }
  }
  // emergency include from pool
  if(xi.length<11){
    for(const p of pool){
      if(xi.length>=11) break;
      if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); }
    }
  }
  return { xi: xi.slice(0,11), threshold: thr, congested, rotatedOut };
}
