import { pickXIWithRotatorPro } from './rotator_pro';
import { simMatchWithEvents } from './sim_structured';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';
import fs from 'fs';

type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number };

function touchPS(state:any, pid:string, stub:{name:string, club:string}){
  const map = state.playerStats ||= {};
  map[pid] ||= { name: stub.name, club: stub.club, goals:0, assists:0, cs:0, yc:0, rc:0, minutes:0, starts:0, formLast5:[] };
  return map[pid];
}
function pushForm(ps:any, rating:number){ ps.formLast5.push(rating); if(ps.formLast5.length>5) ps.formLast5.shift(); }
function ratingFromEvents(ev:{goals:number;assists:number;cards:number}){ return Math.max(5, Math.min(9.5, 6.5 + ev.goals*0.7 + ev.assists*0.4 - ev.cards*0.2)); }
function avg(a:number[]){ return a.length? a.reduce((x,y)=>x+y,0)/a.length : 0; }

export async function advanceWeekV5(state:SeasonState, root:string){
  const squadsPath = root+'/data/squads.csv';
  (state as any).playerStats ||= {};
  (state as any).matchLogs ||= {};
  (state as any).playerFitness ||= {};
  (state as any).fitnessHistory ||= {};   // {pid:[{week, fitness, fatigue}]}
  (state as any).minutesHistory ||= {};   // {pid:[{week, minutes}]}

  const todays = state.fixtures.filter(f=>f.week===state.week);
  for(const fx of todays){
    const { xi:xiHome } = pickXIWithRotatorPro(fx.home, state, squadsPath);
    const { xi:xiAway } = pickXIWithRotatorPro(fx.away, state, squadsPath);
    const sim = simMatchWithEvents(fx.home, fx.away, xiHome as any, xiAway as any);
    applyTable(state.table, fx, {home:sim.score.home, away:sim.score.away});

    // hydrate stats from structured events
    const perMatch: Record<string,{goals:number;assists:number;cards:number}> = {};
    function bump(pid:string, k:'goals'|'assists'|'cards'){ (perMatch[pid] ||= {goals:0,assists:0,cards:0})[k]++; }

    for(const e of sim.events){
      if(e.type==='goal' && e.player){
        const p = findByName(xiHome, xiAway, e.player); if(p){ bump(p.player_id,'goals'); const ps = touchPS(state,p.player_id,{name:p.name, club:p.club||clubOf(p,fx,xiHome,xiAway)}); ps.goals++; }
        if(e.assist){ const a = findByName(xiHome, xiAway, e.assist); if(a){ bump(a.player_id,'assists'); const ps = touchPS(state,a.player_id,{name:a.name, club:a.club||clubOf(a,fx,xiHome,xiAway)}); ps.assists++; } }
      }
      if(e.type==='yc' && e.player){ const p = findByName(xiHome, xiAway, e.player); if(p){ bump(p.player_id,'cards'); const ps = touchPS(state,p.player_id,{name:p.name, club:clubOf(p,fx,xiHome,xiAway)}); ps.yc++; } }
      if(e.type==='rc' && e.player){ const p = findByName(xiHome, xiAway, e.player); if(p){ bump(p.player_id,'cards'); const ps = touchPS(state,p.player_id,{name:p.name, club:clubOf(p,fx,xiHome,xiAway)}); ps.rc++; state.suspensions[p.player_id]=(state.suspensions[p.player_id]||0)+1; } }
    }
    // clean sheets
    if(sim.score.away===0){ const gk = xiHome.find(p=>p.pos==='GK')||xiHome[0]; touchPS(state,gk.player_id,{name:gk.name, club:fx.home}).cs++; }
    if(sim.score.home===0){ const gk = xiAway.find(p=>p.pos==='GK')||xiAway[0]; touchPS(state,gk.player_id,{name:gk.name, club:fx.away}).cs++; }

    // minutes & form
    const played = [...xiHome, ...xiAway];
    for(const p of played){
      const ps = touchPS(state,p.player_id,{name:p.name, club: clubOf(p,fx,xiHome,xiAway)});
      ps.starts += 1; ps.minutes += 90;
      const ev = perMatch[p.player_id] || {goals:0,assists:0,cards:0};
      const rating = ratingFromEvents(ev);
      pushForm(ps, rating);
      // snapshot minutes history
      (state as any).minutesHistory[p.player_id] ||= [];
      (state as any).minutesHistory[p.player_id].push({week: state.week, minutes: 90});
    }

    // save logs
    const id = `${state.week}-${fx.home}-${fx.away}`;
    (state as any).matchLogs[id] = sim.events;
  }

  // snapshot fitness history for all tracked players
  const fit = (state as any).playerFitness || {};
  Object.keys(fit).forEach(pid=>{
    (state as any).fitnessHistory[pid] ||= [];
    (state as any).fitnessHistory[pid].push({week: state.week, fitness: Math.round(fit[pid].fitness), fatigue: Math.round(fit[pid].fatigue)});
  });

  state.week += 1; 
  return state;
}

function findByName(home:any[], away:any[], name:string){
  const p = home.find(p=>p.name===name) || away.find(p=>p.name===name);
  if(!p) return null; return p;
}
function clubOf(p:any, fx:any, xiH:any[], xiA:any[]){
  return xiH.some(x=>x.player_id===p.player_id) ? fx.home : fx.away;
}
