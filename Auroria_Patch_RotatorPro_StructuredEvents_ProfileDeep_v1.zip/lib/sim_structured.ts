type Event = { min:number; type:'goal'|'shot'|'yc'|'rc'|'injury'|'final'|'kickoff'; club?:string; player?:string; assist?:string; x?:number; y?:number; shot_type?:'header'|'foot'|'volley'|'long'; xg?:number };
type XI = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number }[];

function r(){ return Math.random(); }
function ri(a:number,b:number){ return a + Math.floor(Math.random()*(b-a+1)); }
function pick<T>(arr:T[]){ return arr[Math.floor(Math.random()*arr.length)]; }

function pickWeighted<T extends {pos:string}>(arr:T[], weights:any){
  const bucket = arr.map(p=>({p, w: weights[p.pos as keyof typeof weights] ?? 1 }));
  const sum = bucket.reduce((a,b)=>a+b.w,0);
  let rr = Math.random()*sum;
  for(const b of bucket){ rr-=b.w; if(rr<=0) return b.p; }
  return bucket[bucket.length-1].p;
}

function shotType(){ const t = r(); return t<0.1?'header': t<0.8?'foot': t<0.95?'volley':'long'; }
function randomLoc(club:'home'|'away'){ // 0..100, 0 near home goal, 100 near away goal
  const x = club==='home' ? ri(55,96) : ri(4,45);
  const y = ri(10,90);
  return {x,y};
}
function xGFromLocAndType(x:number, shot_type:string){
  // crude xG: closer to goal → higher; center better than wide; long shot small
  const dist = Math.abs(100 - x); // assume attacking to 100
  let base = Math.max(0.02, Math.min(0.65, (40 - dist)/70 ));
  if(shot_type==='long') base*=0.5;
  if(shot_type==='header') base*=0.8;
  return Math.max(0.01, Math.min(0.8, base));
}

export function simMatchWithEvents(homeId:string, awayId:string, xiHome:XI, xiAway:XI){
  const events: Event[] = [{min:0, type:'kickoff'}];
  let goalsH=0, goalsA=0;
  // ~10-22 shot attempts total
  const attempts = ri(10,22);
  for(let i=0;i<attempts;i++){
    const min = ri(3,88);
    const side = r()<0.52 ? 'home' : 'away';
    const xi = side==='home'? xiHome: xiAway;
    const club = side==='home'? homeId: awayId;
    const shooter = pickWeighted(xi, {FW:5,MF:3,DF:1,GK:0.2});
    const ast = pick(xi.filter(p=>p.player_id!==shooter.player_id));
    const st = shotType();
    const loc = randomLoc(side);
    const xg = xGFromLocAndType(side==='home'?loc.x:(100-loc.x), st);
    const goal = r() < xg*0.9; // little dampening
    events.push({min, type:'shot', club, player: shooter.name, assist: ast.name, x:loc.x, y:loc.y, shot_type:st, xg: Number(xg.toFixed(2))});
    if(goal){
      events.push({min, type:'goal', club, player: shooter.name, assist: ast.name, x:loc.x, y:loc.y, shot_type:st, xg: Number(xg.toFixed(2))});
      if(side==='home') goalsH++; else goalsA++;
    }
  }
  // few cards
  const ycN = ri(0,5);
  for(let i=0;i<ycN;i++){
    const side = r()<0.5?'home':'away';
    const xi = side==='home'? xiHome: xiAway;
    const club = side==='home'? homeId: awayId;
    const p = pick(xi);
    events.push({min:ri(5,85), type:'yc', club, player:p.name});
  }
  const rcN = ri(0,1);
  for(let i=0;i<rcN;i++){
    const side = r()<0.5?'home':'away';
    const xi = side==='home'? xiHome: xiAway;
    const club = side==='home'? homeId: awayId;
    const p = pick(xi);
    events.push({min:ri(20,85), type:'rc', club, player:p.name});
  }
  events.push({min:90, type:'final'});
  events.sort((a,b)=> a.min-b.min);
  return { score:{home:goalsH, away:goalsA}, events };
}
