import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';

export async function GET(_:Request, { params }:{ params:{ playerId:string }}){
  try{
    const pid = params.playerId;
    const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
    const ps = state.playerStats?.[pid] || null;
    if(!ps) return NextResponse.json({ error:'NOT_FOUND' }, {status:404});
    const fitnessHist = (state.fitnessHistory?.[pid]||[]);
    const minutesHist = (state.minutesHistory?.[pid]||[]);
    return NextResponse.json({
      player_id: pid, name: ps.name, club: ps.club,
      formLast5: ps.formLast5||[],
      fitnessHistory: fitnessHist, minutesHistory: minutesHist
    });
  }catch(e:any){
    return NextResponse.json({ error:'PLAYER_DEEP_ERROR', message:e?.message }, {status:500});
  }
}
