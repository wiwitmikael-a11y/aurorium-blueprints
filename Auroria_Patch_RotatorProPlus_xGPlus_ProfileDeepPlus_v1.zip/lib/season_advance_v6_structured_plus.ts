import { pickXIWithRotatorProPlus } from './rotator_pro_plus';
import { simMatchWithEventsPlus } from './sim_structured_plus';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';

function touchPS(state:any, pid:string, stub:{name:string, club:string}){
  const map = state.playerStats ||= {};
  map[pid] ||= { name: stub.name, club: stub.club, goals:0, assists:0, cs:0, yc:0, rc:0, minutes:0, starts:0, saves:0, formLast5:[] };
  return map[pid];
}
function pushForm(ps:any, rating:number){ ps.formLast5.push(rating); if(ps.formLast5.length>5) ps.formLast5.shift(); }
function ratingOutfield(ev:{goals:number;assists:number;cards:number}){ return Math.max(5, Math.min(9.5, 6.5 + ev.goals*0.7 + ev.assists*0.4 - ev.cards*0.2)); }
function ratingGK(saves:number, goalsAgainst:number, cs:boolean){ 
  let r = 6.4 + saves*0.15 - goalsAgainst*0.25 + (cs?0.5:0);
  return Math.max(5.0, Math.min(9.7, r));
}

export async function advanceWeekV6(state:SeasonState, root:string){
  (state as any).playerStats ||= {};
  (state as any).matchLogs ||= {};
  (state as any).playerFitness ||= {};
  (state as any).minutesHistory ||= {};
  (state as any).fitnessHistory ||= {};
  (state as any).injuryHistory ||= {};   // {pid: [{week, weeks, kind}]}

  const squadsCsv = await (await import('fs/promises')).readFile(root+'/data/squads.csv','utf-8');
  const lines = squadsCsv.trim().split(/\r?\n/); const hdr = lines.shift()!.split(','); const idx:Record<string,number> = {}; hdr.forEach((h,i)=> idx[h]=i);
  const rows = lines.map(l=>{ const c=l.split(','); return { club:c[idx['club_id']], player_id:c[idx['player_id']], name:c[idx['name']], pos:c[idx['pos']], ovr:Number(c[idx['ovr']]) }; });

  const todays = state.fixtures.filter((f:any)=> f.week===state.week);
  for(const fx of todays){
    const xiHome = pickXIWithRotatorProPlus(fx.home, state, root+'/data/squads.csv', fx.importance).xi as any[];
    const xiAway = pickXIWithRotatorProPlus(fx.away, state, root+'/data/squads.csv', fx.importance).xi as any[];
    const gkHome = xiHome.find(p=>p.pos==='GK') || xiHome[0];
    const gkAway = xiAway.find(p=>p.pos==='GK') || xiAway[0];

    const sim = simMatchWithEventsPlus(fx.home, fx.away, xiHome, xiAway, gkHome, gkAway, (state as any).playerFitness);

    applyTable(state.table, fx, {home:sim.score.home, away:sim.score.away});
    const perMatch: Record<string,{goals:number;assists:number;cards:number; minutes:number}> = {};

    for(const e of sim.events){
      if(e.type==='goal' && e.player){
        const p = findByName([xiHome,xiAway], e.player)!;
        const club = clubOf(p, fx, xiHome, xiAway);
        const ps = touchPS(state, p.player_id, {name:p.name, club});
        ps.goals++; bump(perMatch, p.player_id, 'goals', 0);
        if(e.assist){
          const a = findByName([xiHome,xiAway], e.assist);
          if(a){ touchPS(state, a.player_id, {name:a.name, club: clubOf(a,fx,xiHome,xiAway)}).assists++; bump(perMatch, a.player_id,'assists',0); }
        }
      }
      if(e.type==='yc' && e.player){
        const p = findByName([xiHome,xiAway], e.player)!; const ps = touchPS(state, p.player_id, {name:p.name, club:clubOf(p,fx,xiHome,xiAway)}); ps.yc++; bump(perMatch,p.player_id,'cards',0);
      }
      if(e.type==='rc' && e.player){
        const p = findByName([xiHome,xiAway], e.player)!; const ps = touchPS(state, p.player_id, {name:p.name, club:clubOf(p,fx,xiHome,xiAway)}); ps.rc++; bump(perMatch,p.player_id,'cards',0);
        state.suspensions[p.player_id] = (state.suspensions[p.player_id]||0)+1;
      }
      if(e.type==='save' && e.player){
        const gk = findByName([ [gkHome], [gkAway] ], e.player)!;
        touchPS(state, gk.player_id, {name:gk.name, club: clubOf(gk,fx,[gkHome],[gkAway])}).saves++;
      }
    }

    // minutes & form
    const played = [...xiHome, ...xiAway];
    for(const p of played){
      const club = clubOf(p, fx, xiHome, xiAway);
      const ps = touchPS(state, p.player_id, {name:p.name, club});
      ps.starts += 1; ps.minutes += 90;
      bump(perMatch, p.player_id, 'minutes', 90);
    }
    // form calc
    const goalsAgainstHome = sim.score.away, goalsAgainstAway = sim.score.home;
    for(const p of xiHome){
      const pm = perMatch[p.player_id] || {goals:0,assists:0,cards:0,minutes:90};
      const isGK = p.pos==='GK';
      const saves = isGK ? (sim.saves.home) : 0;
      const rating = isGK ? ratingGK(saves, goalsAgainstHome, sim.score.away===0) : ratingOutfield(pm);
      pushForm(state.playerStats[p.player_id], rating);
    }
    for(const p of xiAway){
      const pm = perMatch[p.player_id] || {goals:0,assists:0,cards:0,minutes:90};
      const isGK = p.pos==='GK';
      const saves = isGK ? (sim.saves.away) : 0;
      const rating = isGK ? ratingGK(saves, goalsAgainstAway, sim.score.home===0) : ratingOutfield(pm);
      pushForm(state.playerStats[p.player_id], rating);
    }

    // clean sheets
    if(sim.score.away===0){ const gk = gkHome; state.playerStats[gk.player_id].cs++; }
    if(sim.score.home===0){ const gk = gkAway; state.playerStats[gk.player_id].cs++; }

    // save logs
    const id = `${state.week}-${fx.home}-${fx.away}`;
    (state as any).matchLogs[id] = sim.events;
  }

  // snapshot fitness minutes already handled in previous patch; keep compatible
  const fit = (state as any).playerFitness || {};
  Object.keys(fit).forEach(pid=>{
    (state as any).fitnessHistory[pid] ||= [];
    (state as any).fitnessHistory[pid].push({week: state.week, fitness: Math.round(fit[pid].fitness), fatigue: Math.round(fit[pid].fatigue)});
  });

  state.week += 1;
  return state;
}

function findByName(groups:any[][], name:string){
  for(const arr of groups){ const p = arr.find(x=>x.name===name); if(p) return p; }
  return null;
}
function clubOf(p:any, fx:any, xiH:any[], xiA:any[]){
  return xiH.some((x:any)=>x.player_id===p.player_id) ? fx.home : fx.away;
}
function bump(m:any, pid:string, k:'goals'|'assists'|'cards'|'minutes', v:number){ (m[pid] ||= {goals:0,assists:0,cards:0,minutes:0})[k]+= (v||1); }
