import { loadSquadsCsv } from './lineup_lock';
type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number; age?:number };

function avg(arr:number[]){ return arr.length? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }
function isUnavailable(state:any, pid:string){
  const ban = state?.suspensions?.[pid] || 0;
  const inj = state?.injuries?.[pid]?.weeks || 0;
  return (ban>0) || (inj>0);
}
function fitnessOf(state:any, pid:string){ return state?.playerFitness?.[pid]?.fitness ?? 85; }
function formAvgOf(state:any, pid:string){ const ps = state?.playerStats?.[pid]; return ps ? avg(ps.formLast5||[]) : 0; }
function getAge(state:any, pid:string){ return state?.playerBio?.[pid]?.age ?? 27; }

function fixtureImportanceAdjust(state:any){
  // priority: explicit flag on state or fixture-level (set by caller)
  const imp = state?.meta?.fixtureImportance || 'normal'; // 'normal' | 'derby' | 'final'
  if(imp==='final') return -7; // lower threshold → berani ambil risiko
  if(imp==='derby') return -4;
  return 0;
}

export function pickXIWithRotatorProPlus(clubId:string, state:any, squadsPath:string, fixtureImportance?:'normal'|'derby'|'final'){
  const map = loadSquadsCsv(squadsPath) as Record<string, Player[]>;
  const pool = (map[clubId]||[]).slice().sort((a,b)=> b.ovr-a.ovr);
  const available = pool.filter(p=> !isUnavailable(state,p.player_id));
  const need = { GK:1, DF:4, MF:4, FW:2 };
  const byPos = { GK: available.filter(p=>p.pos==='GK'),
                  DF: available.filter(p=>p.pos==='DF'),
                  MF: available.filter(p=>p.pos==='MF'),
                  FW: available.filter(p=>p.pos==='FW') };

  const baseThresh = 55;
  const congestionBoost = state?.meta?.congestedWeek ? 5 : 0;
  const impAdj = fixtureImportance ? (fixtureImportance==='final'?-7: (fixtureImportance==='derby'?-4:0)) : fixtureImportanceAdjust(state);
  // role aware deltas:
  // - DF veterans (age>=30) : -3 (lebih berani mainkan)
  // - FW stricter          : +3 (rotasi lebih ketat)
  // - GK neutral           : 0
  const roleDelta = (pos:string, pid:string)=>{
    if(pos==='DF' && getAge(state,pid)>=30) return -3;
    if(pos==='FW') return +3;
    return 0;
  };

  const xi: Player[] = [];
  const rotatedOut: {player_id:string; fitness:number; form:number; reason:string}[] = [];
  (['GK','DF','MF','FW'] as const).forEach(pos=>{
    let cand = byPos[pos].slice();
    cand.sort((a,b)=>{
      const fa = fitnessOf(state,a.player_id), fb = fitnessOf(state,b.player_id);
      const aa = formAvgOf(state,a.player_id), ab = formAvgOf(state,b.player_id);
      const thrA = baseThresh + congestionBoost + impAdj + roleDelta(pos, a.player_id);
      const thrB = baseThresh + congestionBoost + impAdj + roleDelta(pos, b.player_id);
      const borderA = thrA - 5, borderB = thrB - 5;
      const aBorder = (fa < thrA) && (fa >= borderA) && (aa >= 7.2);
      const bBorder = (fb < thrB) && (fb >= borderB) && (ab >= 7.2);
      const aKey = (fa>=thrA)?0: (aBorder?1:2);
      const bKey = (fb>=thrB)?0: (bBorder?1:2);
      if(aKey!==bKey) return aKey-bKey;
      if(b.ovr!==a.ovr) return b.ovr-a.ovr;
      return ab-aa;
    });
    const chosen = cand.slice(0, need[pos]);
    xi.push(...chosen);
    // non-chosen due to low fitness mark
    cand.slice(need[pos]).forEach(p=>{
      const fBase = baseThresh + congestionBoost + impAdj + roleDelta(pos, p.player_id);
      const f = fitnessOf(state,p.player_id);
      if(f < fBase) rotatedOut.push({player_id:p.player_id, fitness: Math.round(f), form: Number(formAvgOf(state,p.player_id).toFixed(2)), reason: `${pos} thr ${fBase}` });
    });
  });

  // fill to 11
  const ids = new Set(xi.map(p=>p.player_id));
  for(const p of available){
    if(xi.length>=11) break;
    if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); }
  }
  if(xi.length<11){
    for(const p of pool){
      if(xi.length>=11) break;
      if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); }
    }
  }

  const thresholdReport = baseThresh + congestionBoost + impAdj;
  return { xi: xi.slice(0,11), thresholdBase: thresholdReport, congested: Boolean(state?.meta?.congestedWeek), rotatedOut };
}
