type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number };
type XI = Player[];
type Event = { min:number; type:'shot'|'goal'|'save'|'yc'|'rc'|'injury'|'final'|'kickoff'; club?:string; player?:string; assist?:string; x?:number; y?:number; shot_type?:'header'|'foot'|'volley'|'long'; xg?:number; assist_type?:'cross'|'through'|'cutback' };

function r(){ return Math.random(); }
function ri(a:number,b:number){ return a + Math.floor(Math.random()*(b-a+1)); }
function pick<T>(arr:T[]){ return arr[Math.floor(Math.random()*arr.length)]; }
function pickWeighted<T extends {pos:string}>(arr:T[], weights:any){
  const bucket = arr.map(p=>({p, w: weights[p.pos as keyof typeof weights] ?? 1 }));
  const sum = bucket.reduce((a,b)=>a+b.w,0);
  let rr = Math.random()*sum;
  for(const b of bucket){ rr-=b.w; if(rr<=0) return b.p; }
  return bucket[bucket.length-1].p;
}

function shotType(){ const t = r(); return t<0.1?'header': t<0.75?'foot': t<0.9?'volley':'long'; }
function assistType(shot:'header'|'foot'|'volley'|'long', x:number, y:number):'cross'|'through'|'cutback'{
  if(shot==='header') return 'cross';
  if(x>80 && Math.abs(y-50)<15) return 'cutback';
  return 'through';
}

function randomLoc(attackingRight:boolean){
  // field 0..100; attackingRight=true means team attacks toward x=100
  const x = attackingRight ? ri(55,96) : ri(4,45);
  const y = ri(10,90);
  return {x,y};
}
function goldenZoneMultiplier(x:number,y:number, attackingRight:boolean){
  // golden zone: central box ~ penalty area
  const ax = attackingRight ? x : (100-x);
  const center = Math.abs(y-50);
  const inBox = (ax>=78 && ax<=96) && (center<=20);
  const golden = (ax>=83 && ax<=94) && (center<=12);
  return golden ? 1.35 : (inBox ? 1.15 : 1.0);
}
function xGBaseFromLocType(ax:number, shot_type:string){
  // ax: distance to attacking goal (0..100 from own half; larger means closer)
  const dist = 100 - ax;
  let base = Math.max(0.02, Math.min(0.65, (40 - dist)/70 ));
  if(shot_type==='long') base*=0.5;
  if(shot_type==='header') base*=0.8;
  return base;
}

export function simMatchWithEventsPlus(homeId:string, awayId:string, xiHome:XI, xiAway:XI, gkHome:Player, gkAway:Player, fitness:any){
  const events: Event[] = [{min:0, type:'kickoff'}];
  let goalsH=0, goalsA=0, savesH=0, savesA=0;

  const attempts = ri(12,24);
  for(let i=0;i<attempts;i++){
    const min = ri(3,88);
    const sideHome = r()<0.52;
    const side = sideHome ? 'home':'away';
    const xi = side==='home'? xiHome: xiAway;
    const club = side==='home'? homeId: awayId;
    const shooter = pickWeighted(xi, {FW:5,MF:3,DF:1,GK:0.1});
    const ast = pick(xi.filter(p=>p.player_id!==shooter.player_id));
    const st = shotType();
    const loc = randomLoc(side==='home');
    const assist_t = assistType(st, loc.x, loc.y);
    const ax = side==='home'? loc.x : (100-loc.x);
    let xg = xGBaseFromLocType(ax, st) * goldenZoneMultiplier(loc.x, loc.y, side==='home');
    xg = Math.max(0.01, Math.min(0.9, xg));

    // keeper save model
    const gk = side==='home'? gkAway : gkHome; // defending keeper
    const gkFit = Math.round(fitness?.[gk.player_id]?.fitness ?? 85);
    const gkSkill = (gk.ovr || 70);
    // save boost ~ higher for better/fit GK
    const saveBoost = (gkSkill-70)/100 + (gkFit-70)/120; // ~ -0.2..+0.5
    const pGoal = Math.max(0.02, Math.min(0.95, xg * (1.0 - 0.35*saveBoost))); // GK reduces conversion
    const isGoal = Math.random() < pGoal;

    events.push({min, type:'shot', club, player: shooter.name, assist: ast.name, x:loc.x, y:loc.y, shot_type:st, xg: Number(xg.toFixed(2)), assist_type: assist_t});

    if(isGoal){
      events.push({min, type:'goal', club, player: shooter.name, assist: ast.name, x:loc.x, y:loc.y, shot_type:st, xg: Number(xg.toFixed(2)), assist_type: assist_t});
      if(side==='home') goalsH++; else goalsA++;
    }else{
      // count save for defending GK (if on target)
      if(Math.random() < 0.75){ // 75% of non-goals considered on-target saves
        events.push({min, type:'save', club: side==='home'? awayId: homeId, player: gk.name});
        if(side==='home') savesA++; else savesH++;
      }
    }
  }
  // cards
  const ycN = ri(0,6);
  for(let i=0;i<ycN;i++){
    const side = r()<0.5?'home':'away';
    const xi = side==='home'? xiHome: xiAway;
    const club = side==='home'? homeId: awayId;
    const p = pick(xi);
    events.push({min:ri(5,85), type:'yc', club, player:p.name});
  }
  const rcN = ri(0,2);
  for(let i=0;i<rcN;i++){
    const side = r()<0.5?'home':'away';
    const xi = side==='home'? xiHome: xiAway;
    const club = side==='home'? homeId: awayId;
    const p = pick(xi);
    events.push({min:ri(25,85), type:'rc', club, player:p.name});
  }

  events.push({min:90, type:'final'});
  events.sort((a,b)=> a.min-b.min);
  return { score:{home:goalsH, away:goalsA}, saves:{home:savesH, away:savesA}, events };
}
