import { NextResponse } from 'next/server';
import { readFile, writeFile } from 'fs/promises';
import { advanceWeekV6 } from '../../../../lib/season_advance_v6_structured_plus';

export async function POST(){
  try{
    const statePath = process.cwd()+'/data/season_state.json';
    const state = JSON.parse(await readFile(statePath,'utf-8'));
    const newState = await advanceWeekV6(state, process.cwd());
    await writeFile(statePath, JSON.stringify(newState,null,2), 'utf-8');
    return NextResponse.json({ ok:true, week:newState.week });
  }catch(e:any){
    return NextResponse.json({ ok:false, error:'ADVANCE_FAILED', message:e?.message }, {status:500});
  }
}
