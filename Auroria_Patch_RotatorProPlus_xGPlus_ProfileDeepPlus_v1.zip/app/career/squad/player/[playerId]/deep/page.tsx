import Shell from '../../../../../../components/Shell';

async function getData(id:string){ 
  const base = process.env.NEXT_PUBLIC_BASE_URL;
  const [d1, d2] = await Promise.all([
    fetch(base + '/api/player/'+id+'/deep', { cache:'no-store' }),
    fetch(base + '/api/season/state', { cache:'no-store' }),
  ]);
  const deep = await d1.json(); const st = await d2.json();
  return { deep, st };
}
export default async function Page({ params }:{ params:{ playerId:string }}){
  const { deep, st } = await getData(params.playerId);
  const injuries = (st.injuryHistory?.[params.playerId] || []);
  return (<Shell>
    <h1 className="text-xl mb-4">{deep.name} — Deep Profile+</h1>
    <div className="grid gap-4 grid-cols-1 lg:grid-cols-3">
      <div className="panel"><h2 className="font-semibold mb-2">Form (last 5)</h2><Sparkline values={deep.formLast5||[]}/></div>
      <div className="panel"><h2 className="font-semibold mb-2">Minutes vs Fitness</h2><Overlay minutes={deep.minutesHistory||[]} fitness={deep.fitnessHistory||[]}/></div>
      <div className="panel"><h2 className="font-semibold mb-2">Injury Timeline</h2><InjuryTimeline items={injuries}/></div>
    </div>
  </Shell>);
}

function Sparkline({values}:{values:number[]}){
  const w=260,h=80,p=10;
  const min = 5, max = 10;
  const pts = values.map((v,i)=>{
    const x = p + (i*(w-2*p))/Math.max(1,(values.length-1));
    const y = h - p - ((v-min)/(max-min||1))*(h-2*p);
    return `${x},${y}`;
  }).join(' ');
  return (<svg width={w} height={h}><polyline fill="none" stroke="currentColor" strokeWidth="2" points={pts}/></svg>);
}

function Overlay({minutes, fitness}:{minutes:{week:number, minutes:number}[], fitness:{week:number, fitness:number}[]}){
  const w=340,h=120,p=12;
  const maxM = Math.max(90,...minutes.map((m:any)=>m.minutes||0));
  // bars for minutes
  const bw = (w-2*p)/Math.max(1, minutes.length||1);
  const minWeeks = Math.max(minutes.length, fitness.length);
  const fx = (i:number)=> p + i*bw;
  const fitPts = (fitness||[]).map((f:any,i:number)=>{
    const x = fx(i)+ bw*0.4;
    const y = h - p - ((f.fitness||0)/100)*(h-2*p);
    return `${x},${y}`;
  }).join(' ');
  return (<svg width={w} height={h}>
    {(minutes||[]).map((m:any,i:number)=>{
      const x = fx(i);
      const bh = ((m.minutes||0)/maxM)*(h-2*p);
      const y = h - p - bh;
      return <rect key={i} x={x} y={y} width={bw*0.8} height={bh} fill="currentColor" opacity="0.35"/>;
    })}
    <polyline fill="none" stroke="currentColor" strokeWidth="2" points={fitPts}/>
  </svg>);
}

function InjuryTimeline({items}:{items:{week:number,weeks:number,kind?:string}[]}){
  const w=340,h=60,p=10;
  const total = Math.max(1, ...items.map((x:any)=> (x.week + (x.weeks||1)) ));
  const scale = (t:number)=> p + (t/Math.max(1,total))*(w-2*p);
  return (<svg width={w} height={h}>
    {/* baseline */}
    <line x1={p} y1={h/2} x2={w-p} y2={h/2} stroke="currentColor" strokeWidth="2" opacity="0.3"/>
    {(items||[]).map((it:any,idx:number)=>{
      const x1 = scale(it.week), x2 = scale(it.week + (it.weeks||1));
      return <line key={idx} x1={x1} y1={h/2} x2={x2} y2={h/2} stroke="currentColor" strokeWidth="6" />;
    })}
  </svg>);
}
