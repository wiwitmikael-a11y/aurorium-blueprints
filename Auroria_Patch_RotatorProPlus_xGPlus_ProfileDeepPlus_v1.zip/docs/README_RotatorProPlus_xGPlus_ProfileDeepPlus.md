
# Patch — Rotator Pro+ + xG+ & Keeper Model + Profile Deep+

## Rotator Pro+ (role-aware & fixture importance)
- File: `lib/rotator_pro_plus.ts`
- Threshold dasar 55
  - **Congested week** → +5 (lebih ketat)
  - **Final** → −7, **Derby** → −4 (lebih agresif menurunkan threshold)
  - **Role-aware**: DF veteran (≥30y) −3; FW +3; GK 0
- Pakai: `pickXIWithRotatorProPlus(clubId, state, squads.csv, fx.importance?)`

## Structured Events xG+ & Keeper Model
- File: `lib/sim_structured_plus.ts`
  - `shot` berisi `x,y,shot_type,assist_type,xg`
  - **Golden zone multiplier** untuk xG
  - **Keeper save model**: konversi gol turun saat GK OVR/fitness tinggi; event `save` + counter saves
- Engine: `lib/season_advance_v6_structured_plus.ts`
  - Pakai Rotator Pro+
  - Update stats: goals, assists, YC/RC, **saves**, CS, minutes, form (GK pakai rumus khusus)
  - Logs terstruktur: `state.matchLogs[week-home-away]`

## Profile Deep+
- Page: `/career/squad/player/:id/deep`
  - **Minutes vs Fitness overlay** (bars + line)
  - **Injury timeline** (membaca `state.injuryHistory[pid]` bila tersedia)

## Integrasi
- Route advance (dipatch) → V6
- Tandai importance opsional per fixture:
  ```json
  { "week": 12, "home": "GEU", "away": "UMN", "importance": "derby" }
  ```
- Untuk injury timeline, saat engine injury trigger (dari patch V4 atau custom), tambahkan:
  ```js
  state.injuryHistory[pid] ||= [];
  state.injuryHistory[pid].push({ week: state.week, weeks: N, kind: 'moderate' });
  ```
