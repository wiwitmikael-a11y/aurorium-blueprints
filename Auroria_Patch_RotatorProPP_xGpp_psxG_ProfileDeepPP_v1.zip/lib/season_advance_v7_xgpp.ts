import { pickXIWithRotatorProPP } from './rotator_pro_pp';
import { simMatchWithEventsXGPP } from './sim_structured_xgpp';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';

function touchPS(state:any, pid:string, stub:{name:string, club:string}){
  const map = state.playerStats ||= {};
  map[pid] ||= { name: stub.name, club: stub.club, goals:0, assists:0, cs:0, yc:0, rc:0, minutes:0, starts:0, saves:0, formLast5:[] };
  return map[pid];
}
function pushForm(ps:any, rating:number){ ps.formLast5.push(rating); if(ps.formLast5.length>5) ps.formLast5.shift(); }
function ratingOutfield(ev:{goals:number;assists:number;cards:number}){ return Math.max(5, Math.min(9.5, 6.5 + ev.goals*0.7 + ev.assists*0.4 - ev.cards*0.2)); }
function ratingGK(saves:number, ga:number, cs:boolean){ let r = 6.4 + saves*0.15 - ga*0.25 + (cs?0.5:0); return Math.max(5.0, Math.min(9.7, r)); }

export async function advanceWeekV7(state:SeasonState, root:string){
  (state as any).playerStats ||= {};
  (state as any).matchLogs ||= {};
  (state as any).teamXG ||= {}; // {week-home-away:{xg,psxg,home,away}}

  const todays = state.fixtures.filter((f:any)=> f.week===state.week);
  for(const fx of todays){
    const h = pickXIWithRotatorProPP(fx.home, state, root+'/data/squads.csv', fx.importance).xi as any[];
    const a = pickXIWithRotatorProPP(fx.away, state, root+'/data/squads.csv', fx.importance).xi as any[];
    const gkH = h.find(p=>p.pos==='GK') || h[0];
    const gkA = a.find(p=>p.pos==='GK') || a[0];

    const sim = simMatchWithEventsXGPP(fx.home, fx.away, h, a, gkH, gkA, (state as any).playerFitness);

    // aggregate xG / psxG team
    const key = `${state.week}-${fx.home}-${fx.away}`;
    const agg = { home:0, away:0, home_ps:0, away_ps:0 };
    for(const e of sim.events){
      if(e.type==='shot' || e.type==='goal'){
        const isHome = e.club===fx.home;
        if(isHome){ agg.home += (e.xg||0); agg.home_ps += (e.psxg||0); }
        else { agg.away += (e.xg||0); agg.away_ps += (e.psxg||0); }
      }
    }
    (state as any).teamXG[key] = { xg:{home:Number(agg.home.toFixed(2)), away:Number(agg.away.toFixed(2))},
                                   psxg:{home:Number(agg.home_ps.toFixed(2)), away:Number(agg.away_ps.toFixed(2))} };

    applyTable(state.table, fx, {home:sim.score.home, away:sim.score.away});

    const perMatch: Record<string,{goals:number;assists:number;cards:number}> = {};
    for(const e of sim.events){
      if(e.type==='goal' && e.player){
        const p = findByName([h,a], e.player)!;
        const club = clubOf(p, fx, h, a);
        touchPS(state, p.player_id, {name:p.name, club}).goals++; bump(perMatch, p.player_id, 'goals');
        if(e.assist){
          const aP = findByName([h,a], e.assist); if(aP){ touchPS(state, aP.player_id, {name:aP.name, club:clubOf(aP,fx,h,a)}).assists++; bump(perMatch,aP.player_id,'assists'); }
        }
      }
      if(e.type==='yc' && e.player){ const p=findByName([h,a],e.player)!; touchPS(state,p.player_id,{name:p.name,club:clubOf(p,fx,h,a)}).yc++; bump(perMatch,p.player_id,'cards'); }
      if(e.type==='rc' && e.player){ const p=findByName([h,a],e.player)!; touchPS(state,p.player_id,{name:p.name,club:clubOf(p,fx,h,a)}).rc++; bump(perMatch,p.player_id,'cards'); state.suspensions[p.player_id]=(state.suspensions[p.player_id]||0)+1; }
      if(e.type==='save' && e.player){
        const gk = findByName([[h.find(p=>p.pos==='GK')],[a.find(p=>p.pos==='GK')]], e.player)!;
        touchPS(state,gk.player_id,{name:gk.name, club: clubOf(gk,fx,h,a)}).saves++;
      }
    }
    // minutes & form
    for(const p of [...h,...a]){
      const ps = touchPS(state, p.player_id, {name:p.name, club: clubOf(p,fx,h,a)});
      ps.starts += 1; ps.minutes += 90;
      const ev = perMatch[p.player_id] || {goals:0,assists:0,cards:0};
      const isGK = p.pos==='GK';
      const ga = isGK ? (p===gkH? sim.score.away: sim.score.home) : 0;
      const saves = isGK ? (p===gkH? sim.saves.home: sim.saves.away) : 0;
      const rating = isGK ? ratingGK(saves, ga, ga===0) : ratingOutfield(ev);
      pushForm(ps, rating);
    }

    (state as any).matchLogs[key] = sim.events;
  }
  state.week += 1;
  return state;
}

function findByName(groups:any[][], name:string){
  for(const arr of groups){ const p = arr.find(x=>x.name===name); if(p) return p; }
  return null;
}
function clubOf(p:any, fx:any, xiH:any[], xiA:any[]){
  return xiH.some((x:any)=>x.player_id===p.player_id) ? fx.home : fx.away;
}
function bump(m:any, pid:string, k:'goals'|'assists'|'cards'){ (m[pid] ||= {goals:0,assists:0,cards:0})[k]+=1; }
