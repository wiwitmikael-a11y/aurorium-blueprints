import { loadSquadsCsv } from './lineup_lock';
type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number; age?:number };
type TableRow = { club_id:string; pts:number; played:number; gd:number; rank:number };

function avg(arr:number[]){ return arr.length? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }
function isUnavailable(state:any, pid:string){
  const ban = state?.suspensions?.[pid] || 0;
  const inj = state?.injuries?.[pid]?.weeks || 0;
  return (ban>0) || (inj>0);
}
function fitnessOf(state:any, pid:string){ return state?.playerFitness?.[pid]?.fitness ?? 85; }
function formAvgOf(state:any, pid:string){ const ps = state?.playerStats?.[pid]; return ps ? avg(ps.formLast5||[]) : 0; }
function getAge(state:any, pid:string){ return state?.playerBio?.[pid]?.age ?? 27; }

function tableRank(state:any, clubId:string){
  const row = (state.table as TableRow[]).find(r=> r.club_id===clubId);
  return row?.rank ?? 10;
}
function seasonContextImportance(state:any, clubId:string){
  // late season tension: last 6 weeks of season (if season_length exists)
  const seasonLen = state?.meta?.season_length ?? 34;
  const late = (state.week >= seasonLen - 6);
  const rank = tableRank(state, clubId);
  // title race (rank<=3), relegation fight (rank>=season_size-3) → reduce threshold for starters (more risk)
  if(late && rank<=3) return -5;
  if(late && rank>= (state?.meta?.league_size? state.meta.league_size-2 : 16)) return -4;
  return 0;
}
function boardRiskAdj(state:any){
  const risk = state?.board?.risk_appetite || 'normal'; // 'low'|'normal'|'high'
  if(risk==='low') return +3;   // lebih konservatif → threshold naik
  if(risk==='high') return -3;  // lebih agresif → threshold turun
  return 0;
}

export function pickXIWithRotatorProPP(clubId:string, state:any, squadsPath:string, fixtureImportance?:'normal'|'derby'|'final'){
  const map = loadSquadsCsv(squadsPath) as Record<string, Player[]>;
  const pool = (map[clubId]||[]).slice().sort((a,b)=> b.ovr-a.ovr);
  const available = pool.filter(p=> !isUnavailable(state,p.player_id));
  const need = { GK:1, DF:4, MF:4, FW:2 };
  const byPos = { GK: available.filter(p=>p.pos==='GK'),
                  DF: available.filter(p=>p.pos==='DF'),
                  MF: available.filter(p=>p.pos==='MF'),
                  FW: available.filter(p=>p.pos==='FW') };

  const base = 55;
  const congestion = state?.meta?.congestedWeek ? 5 : 0;
  const impFlag = fixtureImportance || state?.meta?.fixtureImportance || 'normal';
  const impAdj = impFlag==='final'? -7 : impFlag==='derby'? -4 : 0;
  const ctxAdj = seasonContextImportance(state, clubId);
  const boardAdj = boardRiskAdj(state);
  const globalBase = base + congestion + impAdj + ctxAdj + boardAdj;

  const roleDelta = (pos:string, pid:string)=>{
    if(pos==='DF' && getAge(state,pid)>=30) return -3;
    if(pos==='FW') return +3;
    return 0;
  };

  const xi: Player[] = [];
  const rotatedOut: {player_id:string; fitness:number; form:number; reason:string}[] = [];
  (['GK','DF','MF','FW'] as const).forEach(pos=>{
    let cand = byPos[pos].slice();
    cand.sort((a,b)=>{
      const fa = fitnessOf(state,a.player_id), fb = fitnessOf(state,b.player_id);
      const aa = formAvgOf(state,a.player_id), ab = formAvgOf(state,b.player_id);
      const thrA = globalBase + roleDelta(pos, a.player_id);
      const thrB = globalBase + roleDelta(pos, b.player_id);
      const aBorder = (fa < thrA) && (fa >= thrA-5) && (aa >= 7.2);
      const bBorder = (fb < thrB) && (fb >= thrB-5) && (ab >= 7.2);
      const aKey = (fa>=thrA)?0: (aBorder?1:2);
      const bKey = (fb>=thrB)?0: (bBorder?1:2);
      if(aKey!==bKey) return aKey-bKey;
      if(b.ovr!==a.ovr) return b.ovr-a.ovr;
      return ab-aa;
    });
    const chosen = cand.slice(0, need[pos]);
    xi.push(...chosen);
    cand.slice(need[pos]).forEach(p=>{
      const thr = globalBase + roleDelta(pos, p.player_id);
      const f = fitnessOf(state,p.player_id);
      if(f < thr) rotatedOut.push({player_id:p.player_id, fitness: Math.round(f), form: Number(formAvgOf(state,p.player_id).toFixed(2)), reason:`${pos} thr ${thr}`});
    });
  });

  // fill to 11
  const ids = new Set(xi.map(p=>p.player_id));
  for(const p of available){ if(xi.length>=11) break; if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); } }
  if(xi.length<11){ for(const p of pool){ if(xi.length>=11) break; if(!ids.has(p.player_id)){ xi.push(p); ids.add(p.player_id); } } }

  return { xi: xi.slice(0,11), thresholdBase: globalBase, rotatedOut };
}
