import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
export async function GET(){
  try{
    const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
    const map = state.scorers || {};
    const rows = Object.entries(map).map(([pid, v]:any)=>({ player_id:pid, ...v }))
      .sort((a:any,b:any)=> b.goals-a.goals).slice(0,50);
    return NextResponse.json({ top: rows });
  }catch(e:any){
    return NextResponse.json({ error:'SCORERS_ERROR', message:e?.message }, {status:500});
  }
}
