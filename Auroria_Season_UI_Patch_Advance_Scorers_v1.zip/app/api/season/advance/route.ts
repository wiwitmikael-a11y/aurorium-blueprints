import { NextResponse } from 'next/server';
import { readFile, writeFile } from 'fs/promises';
import fs from 'fs';
import yaml from 'js-yaml';
import { advanceWeekWithDisciplineAndScorers } from '../../../../lib/season_loop_with_discipline_and_scorers';
import { loadSquadsCsv } from '../../../../lib/scoring';

function safeLoadYaml(path:string){
  try{ return yaml.load(fs.readFileSync(path,'utf-8')); }catch{ return null; }
}

export async function POST(){
  try{
    const root = process.cwd();
    const statePath = root+'/data/season_state.json';
    const league = safeLoadYaml(root+'/configs/league_rules.yaml') || {};
    // support both configs_out (from tuning exporter) and configs defaults
    const discipline = safeLoadYaml(root+'/configs_out/discipline_rules.yaml') || safeLoadYaml(root+'/configs/discipline_rules.yaml') || { table:[] };
    const injury = safeLoadYaml(root+'/configs_out/injury_rates.yaml') || safeLoadYaml(root+'/configs/injury_model.yaml') || {};
    const squads = loadSquadsCsv(root+'/data/squads.csv');
    const state = JSON.parse(await readFile(statePath,'utf-8'));
    const newState = await advanceWeekWithDisciplineAndScorers(state, league, discipline, injury, squads);
    await writeFile(statePath, JSON.stringify(newState,null,2), 'utf-8');
    return NextResponse.json({ ok:true, week:newState.week });
  }catch(e:any){
    return NextResponse.json({ ok:false, error:'ADVANCE_FAILED', message:e?.message }, {status:500});
  }
}
