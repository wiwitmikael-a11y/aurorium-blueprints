import fs from 'fs';
export type SquadsMap = Record<string, {player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'}[]>;

export function loadSquadsCsv(csvPath:string): SquadsMap {
  const txt = fs.readFileSync(csvPath,'utf-8').trim();
  const lines = txt.split(/\r?\n/);
  const hdr = lines.shift()?.split(',')||[];
  const idx = Object.fromEntries(hdr.map((h,i)=>[h,i]));
  const map: SquadsMap = {};
  for(const l of lines){
    const cols = l.split(',');
    const club = cols[idx['club_id']];
    const player_id = cols[idx['player_id']];
    const name = cols[idx['name']];
    const pos = cols[idx['pos']] as any;
    (map[club] ||= []).push({player_id, name, pos});
  }
  return map;
}

function choice<T>(arr:T[]):T{ return arr[Math.floor(Math.random()*arr.length)]; }

export function pickScorer(clubId:string, squads:SquadsMap){
  const squad = squads[clubId]||[];
  if(squad.length===0) return { player_id:`${clubId}-AUTO`, name:`${clubId} Scorer`, pos:'FW' as const };
  // weight by position
  const bucket: {w:number; p:{player_id:string; name:string; pos:any}}[] = [];
  for(const p of squad){
    const w = p.pos==='FW'? 5 : p.pos==='MF'? 3 : p.pos==='DF'? 2 : 1;
    bucket.push({w, p});
  }
  const sum = bucket.reduce((a,b)=>a+b.w,0);
  let r = Math.random()*sum;
  for(const b of bucket){ r-=b.w; if(r<=0) return b.p; }
  return bucket[bucket.length-1].p;
}
