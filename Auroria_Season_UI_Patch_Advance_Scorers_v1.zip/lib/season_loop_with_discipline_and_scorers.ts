import { fastSimMatch } from './sim_fast';
import { applyTable } from './scheduling';
import { pickScorer, SquadsMap } from './scoring';
import type { SeasonState } from './types';

function rand(){ return Math.random(); }
function randMinute(){ return 1 + Math.floor(Math.random()*90); }

export async function advanceWeekWithDisciplineAndScorers(
  state:SeasonState, rules:any, discipline:any, injury:any, squads:SquadsMap
){
  // ensure scorers map exists
  (state as any).scorers ||= {};
  const todays = state.fixtures.filter(f=>f.week===state.week);
  for(const fx of todays){
    const res = fastSimMatch(fx.home, fx.away, rules);
    applyTable(state.table, fx, res);
    // assign scorers per goal
    for(let i=0;i<res.home;i++){
      const s = pickScorer(fx.home, squads);
      (state as any).scorers[s.player_id] ||= {name:s.name, club:fx.home, goals:0};
      (state as any).scorers[s.player_id].goals++;
      state.news.push({t:new Date().toISOString(), msg:`⚽ ${fx.home}: ${s.name} ${randMinute()}'`, tags:['goal','scorer']});
    }
    for(let i=0;i<res.away;i++){
      const s = pickScorer(fx.away, squads);
      (state as any).scorers[s.player_id] ||= {name:s.name, club:fx.away, goals:0};
      (state as any).scorers[s.player_id].goals++;
      state.news.push({t:new Date().toISOString(), msg:`⚽ ${fx.away}: ${s.name} ${randMinute()}'`, tags:['goal','scorer']});
    }
    state.news.push({t:new Date().toISOString(), msg:`Result — ${fx.home} ${res.home}-${res.away} ${fx.away}`, tags:['result']});

    // discipline
    const yProb = Number(discipline?.table?.find((r:any)=>r.event==='foul_caution')?.yellow_prob ?? 0.18);
    const rProb = Number(discipline?.table?.find((r:any)=>r.event==='foul_serious')?.red_prob ?? 0.02);
    const banMatches = Number(discipline?.table?.find((r:any)=>r.event==='foul_serious')?.ban_matches ?? 1);
    if(rand()<yProb) state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.home}: caution`, tags:['discipline']});
    if(rand()<rProb){ state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.home}: red card (ban ${banMatches})`, tags:['discipline']}); state.suspensions[`${fx.home}-AUTO`] = banMatches; }
    if(rand()<yProb) state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.away}: caution`, tags:['discipline']});
    if(rand()<rProb){ state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.away}: red card (ban ${banMatches})`, tags:['discipline']}); state.suspensions[`${fx.away}-AUTO`] = banMatches; }

    // injuries
    const minorP = Number(injury?.severity_split?.minor ?? 0.6);
    const modP   = Number(injury?.severity_split?.moderate ?? 0.3);
    const serP   = Number(injury?.severity_split?.serious ?? 0.1);
    const rate   = Number(injury?.rate_per_match ?? 0.07);
    if(rand()<rate){
      const r = rand(); let kind = 'minor';
      if(r>minorP) kind='moderate';
      if(r>(minorP+modP)) kind='serious';
      const range = injury?.durations_weeks?.[kind] ?? [1,2];
      const weeks = Math.max(range[0], Math.min(range[1], Math.floor(range[0] + rand()*(range[1]-range[0]+1))));
      state.injuries[`${fx.home}-AUTO`] = {weeks};
      state.news.push({t:new Date().toISOString(), msg:`🩹 Injury at ${fx.home}: ${kind} (${weeks}w)`, tags:['injury']});
    }
  }
  // decay
  Object.keys(state.suspensions).forEach(pid=> state.suspensions[pid] = Math.max(0,(state.suspensions[pid]-1)));
  Object.keys(state.injuries).forEach(pid=> state.injuries[pid].weeks = Math.max(0,(state.injuries[pid].weeks-1)));
  state.week += 1; return state;
}
