
# AuroriaDB v1 — Mass Seed 10k + Expanded Synergy
Generated: 2025-09-04T20:21:37.152938Z

## Structure
/AuroriaDB/v1/
  ├─ schema/ (JSON Schemas)
  ├─ data/   (nations, clubs, name pools, synergy rules EXPANDED)
  ├─ sample_generated/ (players_200.json)
  ├─ mass_seed/
  │    ├─ players_10000.json
  │    └─ players_batches/ (5 × 2000)
  └─ docs/
       ├─ CHEMISTRY_FORMULA.md
       └─ README.md

## Notes
- Attributes scale 1–20; Potential 40–200 → rarity (Common/Rare/Epic/Legend).
- Race/nation/element distribution enforced; synergy tags pre-baked.
- Synergy expanded: Duo, Trio, Line, Team with event hooks for match engine.
