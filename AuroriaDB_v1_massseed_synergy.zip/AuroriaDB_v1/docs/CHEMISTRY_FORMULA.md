
# Chemistry Formula (Engine Suggestion)

**Chemistry Score (pair/line/team) = Base + Sum(synergy.effects.chemistry) + Context**

- Base per relationship: Duo=5, Trio=7, Line=8, Team=10
- Add `effects.chemistry` from matched synergy rules (stackable, cap at +20 per relation)
- Context modifiers:
  - Minutes together last 10 matches: +0 to +5
  - Shared language/academy: +0 to +3
  - Personality conflicts (Diva vs Leader): −0 to −4
  - Recent media scandal: −0 to −3

**Runtime Effects Mapping** (example):
- Chemistry 80–100 → +5% pass success, −10% miscommunication, +0.03 xG on combos
- Chemistry 60–79  → +2% pass success, −5% miscommunication
- Chemistry 40–59  → Neutral
- Chemistry 20–39  → −2% pass success, +5% miscommunication
- Chemistry 0–19   → −5% pass success, +10% miscommunication, random blunders

**Event Hooks**: Each synergy rule may define triggers (`on_shot`, `on_cross`, `on_high_press`, etc.). On trigger:
- Check `conditions` (minute, weather, score_diff, line composition)
- Apply `effects` temporarily (e.g., `xg_mod:+0.05`, `block:+1`, `turnover_chance:+0.03`)
- Respect cooldowns in engine implementation.
