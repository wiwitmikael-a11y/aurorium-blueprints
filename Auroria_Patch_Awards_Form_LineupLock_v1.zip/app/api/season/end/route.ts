import { NextResponse } from 'next/server';
import { readFile, writeFile } from 'fs/promises';
import yaml from 'js-yaml';
import { endSeasonWithAwards } from '../../../../lib/end_season_awards';

export async function POST(){
  try{
    const statePath = process.cwd()+'/data/season_state.json';
    const eco = yaml.load(await readFile(process.cwd()+'/configs/economy_config.yaml','utf-8'));
    const state = JSON.parse(await readFile(statePath,'utf-8'));
    const result = endSeasonWithAwards(state, eco);
    await writeFile(statePath, JSON.stringify(state,null,2), 'utf-8');
    return NextResponse.json({ ok:true, result });
  }catch(e:any){
    return NextResponse.json({ ok:false, error:'END_SEASON_FAILED', message:e?.message }, {status:500});
  }
}
