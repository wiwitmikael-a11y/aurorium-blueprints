
# Patch — Awards End-Season + Form & Minutes + Lineup Lock

## Fitur
1) **Lineup Lock**: starting XI otomatis mengecualikan pemain **suspended** / **injured** (lihat `state.suspensions`, `state.injuries`).
2) **Form & Minutes Tracking**: tiap starter mendapatkan:
   - `minutes` (+90 default, -random jika kartu merah)
   - `starts` (+1 per starting XI)
   - `formLast5` (rating 5.0–9.5 dihitung dari gol, assist, clean sheet, kartu)
3) **End-Season Awards**:
   - 🥇 Golden Boot (top goals)
   - 🎯 Playmaker Award (top assists)
   - 🧤 Golden Glove (top clean sheets)
   - Hadiah AC dibaca dari `configs/economy_config.yaml` atau fallback.

## File Utama
- `lib/lineup_lock.ts` → `pickStartingXIWithLock(clubId, squads, state)`
- `lib/season_loop_starters_events_v3.ts` → advance pekanan + minutes/starts/form + lock availability
- `lib/end_season_awards.ts` → processor akhir musim dgn awards
- `app/api/season/end/route.ts` → pakai `endSeasonWithAwards()`

## Integrasi
1. Replace route advance untuk pakai engine v3 (starter+form+lock):
   ```ts
   import { advanceWeekWithStartersEventsV3 } from '../../../lib/season_loop_starters_events_v3';
   // ...
   const newState = await advanceWeekWithStartersEventsV3(state, process.cwd());
   ```
2. Pastikan `configs/economy_config.yaml` punya kunci (opsional):
   ```yaml
   prize_golden_boot: 150000
   prize_playmaker: 120000
   prize_golden_glove: 100000
   ```
3. Jalankan musim penuh → `POST /api/season/end` (halaman `/career/season` sudah ada). News akan berisi champion, relegation, **awards** + hadiah AC.

## Next
- Propagasi **fitness** ke kecenderungan cedera & performa.
- Tambah **Suspension Accumulation** (threshold yellow → auto-ban).
- Ekspos **Form UI** (badge rata-rata 5 match terakhir).
