import type { SeasonState } from './types';

/**
 * Adds Golden Boot, Playmaker, Golden Glove awards with AC prizes.
 * economy_config keys (fallbacks): prize_golden_boot(150000), prize_playmaker(120000), prize_golden_glove(100000)
 */
export function endSeasonWithAwards(state:SeasonState, economy:any){
  const rows = Object.entries(state.table).map(([club,row]:any)=>({club, ...row}))
    .sort((a:any,b:any)=> b.pts-a.pts || b.gd-a.gd || b.gf-a.gf);
  const champion = rows[0]?.club;
  const releg = rows.slice(-3).map(r=>r.club);

  // champion + relegation logs
  state.news.push({t:new Date().toISOString(), msg:`🏆 Champion: ${champion}`, tags:['award','season']});
  releg.forEach(c=> state.news.push({t:new Date().toISOString(), msg:`⬇️ Relegated: ${c}`, tags:['competition']}));

  // player awards
  const stats = (state as any).playerStats || {};
  const list = Object.entries(stats).map(([pid, p]:any)=>({player_id:pid, ...p}));

  const topGoals = list.sort((a,b)=> b.goals-a.goals || a.name.localeCompare(b.name))[0];
  const topAssists = list.sort((a,b)=> b.assists-a.assists || a.name.localeCompare(b.name))[0];
  const topCS = list.sort((a,b)=> b.cs-a.cs || a.name.localeCompare(b.name))[0];

  const prizeBoot = economy?.prize_golden_boot ?? 150000;
  const prizeAssist = economy?.prize_playmaker ?? 120000;
  const prizeGlove = economy?.prize_golden_glove ?? 100000;

  if(topGoals){
    state.news.push({t:new Date().toISOString(), msg:`🥇 Golden Boot: ${topGoals.name} (${topGoals.goals} goals) — ${topGoals.club} +${prizeBoot} AC`, tags:['award']});
  }
  if(topAssists){
    state.news.push({t:new Date().toISOString(), msg:`🎯 Playmaker Award: ${topAssists.name} (${topAssists.assists} assists) — ${topAssists.club} +${prizeAssist} AC`, tags:['award']});
  }
  if(topCS){
    state.news.push({t:new Date().toISOString(), msg:`🧤 Golden Glove: ${topCS.name} (${topCS.cs} clean sheets) — ${topCS.club} +${prizeGlove} AC`, tags:['award']});
  }

  // reset table for next season
  state.week = 1;
  Object.keys(state.table).forEach(club=> state.table[club] = {pts:0,gf:0,ga:0,gd:0,w:0,d:0,l:0});
  return { champion, releg, awards: { boot: topGoals?.player_id, playmaker: topAssists?.player_id, glove: topCS?.player_id } };
}
