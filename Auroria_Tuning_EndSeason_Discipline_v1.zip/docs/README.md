# Auroria — Tuning Sheet + End-Season + Discipline/Injury Hook

## 1) Tuning Sheet
- Edit CSVs in `tuning_templates/`: tactics_weights, odds_base, synergy_weights, economy_config, discipline_rules, injury_rates.
- Run exporter: `node scripts/csv_to_yaml.js --in tuning_templates --out configs_out`
- Replace or merge the generated YAML into your `configs/` in project.

## 2) Discipline/Injury Hook
- Use `advanceWeekWithDiscipline()` from `lib/season_loop_with_discipline.ts` in place of `advanceWeek()`.
- It logs ⚠️ cards & 🩹 injuries to `state.news`, and updates `state.suspensions` / `state.injuries` (decays weekly).
- Integrate with UI (News) & squad availability (block AUTO ids or map to real players when ready).

## 3) End-Season Processor
- POST `/api/season/end` → runs `lib/end_season.ts` to produce:
  - Champion, relegations log
  - Prize payouts (reads `configs/economy_config.yaml`)
  - Sponsor renegotiation placeholder
  - Reset week and clear table for next season
- Add `/career/season` page to run and review logs.

## Implementation Order
1. Start with Tuning Sheets → generate YAMLs.
2. Switch Season Loop to `advanceWeekWithDiscipline()`.
3. Wire `/api/season/end` and test one full season (38 weeks) → run end-season.
4. Iterate: connect real player IDs to cards/injuries, add top-scorer logic, sponsor offers.
