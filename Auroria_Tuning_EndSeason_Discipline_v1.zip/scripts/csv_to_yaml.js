#!/usr/bin/env node
/**
 * Convert CSV tuning sheets into YAML configs.
 * usage: node scripts/csv_to_yaml.js --in tuning_templates --out configs
 */
import fs from 'fs';
import path from 'path';

function parseCSV(text){
  const lines = text.split(/\r?\n/).filter(Boolean);
  if(lines.length===0) return [];
  const headers = lines[0].split(',');
  return lines.slice(1).map(l=>{
    const cols = l.split(',');
    const row = {}; headers.forEach((h,i)=> row[h]=cols[i] ?? '');
    return row;
  });
}

function toNumberOrKeep(s){
  if(s===undefined) return s;
  const n = Number(s);
  return isNaN(n) ? s : n;
}

function main(){
  const args = process.argv.slice(2);
  const inDir = args[args.indexOf('--in')+1] || 'tuning_templates';
  const outDir = args[args.indexOf('--out')+1] || 'configs_out';
  if(!fs.existsSync(outDir)) fs.mkdirSync(outDir, {recursive:true});

  // tactics
  const tactics = parseCSV(fs.readFileSync(path.join(inDir,'tactics_weights.csv'),'utf-8'))
    .reduce((acc,row)=>{ acc[row.key] = toNumberOrKeep(row.value); return acc; }, {});
  fs.writeFileSync(path.join(outDir,'tactics_weights.yaml'), `# generated\n` + yamlDump(tactics));

  // odds
  const odds = parseCSV(fs.readFileSync(path.join(inDir,'odds_base.csv'),'utf-8'))
    .reduce((acc,row)=>{ acc[row.event] = toNumberOrKeep(row.prob); return acc; }, {});
  fs.writeFileSync(path.join(outDir,'odds_base.yaml'), `# generated\n` + yamlDump(odds));

  // synergy weights
  const syRows = parseCSV(fs.readFileSync(path.join(inDir,'synergy_weights.csv'),'utf-8'));
  const sy = {}; syRows.forEach(r=>{
    sy[r.synergy_tag] = { attack_boost: Number(r.attack_boost||0), def_boost: Number(r.def_boost||0), stamina_mod: Number(r.stamina_mod||0) };
  });
  fs.writeFileSync(path.join(outDir,'synergy_weights.yaml'), `# generated\n` + yamlDump(sy));

  // economy
  const eco = parseCSV(fs.readFileSync(path.join(inDir,'economy_config.csv'),'utf-8'))
    .reduce((acc,row)=>{ acc[row.key] = toNumberOrKeep(row.value); return acc; }, {});
  fs.writeFileSync(path.join(outDir,'economy_config.yaml'), `# generated\n` + yamlDump(eco));

  // discipline & injury
  const disc = parseCSV(fs.readFileSync(path.join(inDir,'discipline_rules.csv'),'utf-8'));
  fs.writeFileSync(path.join(outDir,'discipline_rules.yaml'), `# generated\n` + yamlDump({ table:disc }));
  const inj = parseCSV(fs.readFileSync(path.join(inDir,'injury_rates.csv'),'utf-8'));
  fs.writeFileSync(path.join(outDir,'injury_rates.yaml'), `# generated\n` + yamlDump({ table:inj }));

  console.log('Exported YAML to', outDir);
}

// tiny YAML dumper
function yamlDump(obj, indent=0){
  const pad = '  '.repeat(indent);
  if(Array.isArray(obj)){
    return obj.map(v => pad + '- ' + yamlDump(v, indent+1).trimStart()).join('\n') + '\n';
  }else if(obj && typeof obj==='object'){
    return Object.entries(obj).map(([k,v])=>{
      if(v && typeof v==='object'){
        return pad + k + ':\n' + yamlDump(v, indent+1);
      }else{
        return pad + k + ': ' + String(v) + '\n';
      }
    }).join('');
  }else{
    return pad + String(obj) + '\n';
  }
}

main();
