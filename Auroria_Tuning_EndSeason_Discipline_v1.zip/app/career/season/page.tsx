export const dynamic = 'force-dynamic';
async function getState(){
  const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/season/state', { cache:'no-store' });
  return r.json();
}
export default async function Page(){
  const state = await getState();
  const table = Object.entries(state.table).map(([club,row]:any)=>({club, ...row})).sort((a:any,b:any)=> b.pts-a.pts || b.gd-a.gd || b.gf-a.gf);
  return (<main className="p-6 space-y-4">
    <h1 className="text-xl">Season Summary</h1>
    {table.length>0 && <div className="p-3 border rounded">🏆 Champion (current table leader): <b>{table[0].club}</b></div>}
    <form action={async()=>{await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/season/end',{method:'POST'});}}>
      <button className="px-3 py-2 border rounded">Run End-Season</button>
    </form>
    <div className="space-y-2">
      {state.news.slice().reverse().map((n:any,i:number)=>(<div key={i} className="p-2 border rounded">
        <span className="opacity-60">{new Date(n.t).toLocaleString()}</span> — {n.msg}
      </div>))}
    </div>
  </main>);
}
