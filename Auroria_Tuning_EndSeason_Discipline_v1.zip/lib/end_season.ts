import type { SeasonState } from './types';
/**
 * End-season processor:
 * - finalize table (champion, relegation)
 * - assign prize money from economy config
 * - sponsor renegotiation placeholder
 * - awards (team MVP placeholder)
 * - reset week to 1 and carry fixtures to next season (or regenerate externally)
 */
export function endSeason(state:SeasonState, economy:any){
  // ranking
  const rows = Object.entries(state.table).map(([club,row]:any)=>({club, ...row}))
    .sort((a:any,b:any)=> b.pts-a.pts || b.gd-a.gd || b.gf-a.gf);
  const champion = rows[0]?.club;
  const releg = rows.slice(-3).map(r=>r.club);

  // prizes
  const prizeChamp = economy?.prize_apl_champion ?? 500000;
  const prizeRunner = economy?.prize_apl_runnerup ?? 250000;

  state.news.push({t:new Date().toISOString(), msg:`🏆 Champion: ${champion}`, tags:['award','season']});
  state.news.push({t:new Date().toISOString(), msg:`💰 Prize: ${champion} +${prizeChamp} AC`, tags:['finance']});
  if(rows[1]) state.news.push({t:new Date().toISOString(), msg:`💰 Runner-up Prize: ${rows[1].club} +${prizeRunner} AC`, tags:['finance']});
  releg.forEach(c=> state.news.push({t:new Date().toISOString(), msg:`⬇️ Relegated: ${c}`, tags:['competition']}));

  // sponsor renegotiation (placeholder log)
  state.news.push({t:new Date().toISOString(), msg:`📑 Sponsor contracts set for renegotiation`, tags:['sponsor']});

  // reset week (keep fixtures) — or regenerate next season outside
  state.week = 1;
  // clear table
  Object.keys(state.table).forEach(club=> state.table[club] = {pts:0,gf:0,ga:0,gd:0,w:0,d:0,l:0});
  return { champion, releg };
}
