import { fastSimMatch } from './sim_fast';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';

function rand(){ return Math.random(); }

export async function advanceWeekWithDiscipline(state:SeasonState, rules:any, discipline:any, injury:any){
  const todays = state.fixtures.filter(f=>f.week===state.week);
  for(const fx of todays){
    const res = fastSimMatch(fx.home, fx.away, rules);
    applyTable(state.table, fx, res);
    state.news.push({t:new Date().toISOString(), msg:`${fx.home} ${res.home}-${res.away} ${fx.away}`, tags:['result']});

    // simulate cards (team-level → assign to pseudo player ids for now)
    const yProb = Number(discipline?.table?.find((r:any)=>r.event==='foul_caution')?.yellow_prob ?? 0.18);
    const rProb = Number(discipline?.table?.find((r:any)=>r.event==='foul_serious')?.red_prob ?? 0.02);
    const banMatches = Number(discipline?.table?.find((r:any)=>r.event==='foul_serious')?.ban_matches ?? 1);
    // home
    if(rand()<yProb) state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.home}: caution`, tags:['discipline']});
    if(rand()<rProb){ state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.home}: red card (ban ${banMatches})`, tags:['discipline']}); state.suspensions[`${fx.home}-AUTO`] = banMatches; }
    // away
    if(rand()<yProb) state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.away}: caution`, tags:['discipline']});
    if(rand()<rProb){ state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.away}: red card (ban ${banMatches})`, tags:['discipline']}); state.suspensions[`${fx.away}-AUTO`] = banMatches; }

    // simulate injuries
    const minorP = Number(injury?.severity_split?.minor ?? 0.6);
    const modP   = Number(injury?.severity_split?.moderate ?? 0.3);
    const serP   = Number(injury?.severity_split?.serious ?? 0.1);
    const rate   = Number(injury?.rate_per_match ?? 0.07);
    if(rand()<rate){
      const r = rand(); let kind = 'minor';
      if(r>minorP) kind='moderate';
      if(r>(minorP+modP)) kind='serious';
      const range = injury?.durations_weeks?.[kind] ?? [1,2];
      const weeks = Math.max(range[0], Math.min(range[1], Math.floor(range[0] + rand()*(range[1]-range[0]+1))));
      // assign to home by default
      state.injuries[`${fx.home}-AUTO`] = {weeks};
      state.news.push({t:new Date().toISOString(), msg:`🩹 Injury at ${fx.home}: ${kind} (${weeks}w)`, tags:['injury']});
    }
  }
  // decay suspensions/injuries
  Object.keys(state.suspensions).forEach(pid=> state.suspensions[pid] = Math.max(0,(state.suspensions[pid]-1)));
  Object.keys(state.injuries).forEach(pid=> state.injuries[pid].weeks = Math.max(0,(state.injuries[pid].weeks-1)));
  state.week += 1; return state;
}
