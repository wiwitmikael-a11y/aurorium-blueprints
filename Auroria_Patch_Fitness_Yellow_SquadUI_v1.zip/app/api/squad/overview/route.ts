import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import fs from 'fs';

export async function GET(){
  try{
    const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
    const squadsCsv = fs.readFileSync(process.cwd()+'/data/squads.csv','utf-8').trim().split(/\r?\n/);
    const hdr = squadsCsv.shift()!.split(',');
    const idx = Object.fromEntries(hdr.map((h,i)=>[h,i]));
    const rows = squadsCsv.map(l=>{
      const c=l.split(','); 
      return { club:c[idx['club_id']], player_id:c[idx['player_id']], name:c[idx['name']], pos:c[idx['pos']], ovr:Number(c[idx['ovr']]) };
    });
    const stats = state.playerStats||{};
    const fit = state.playerFitness||{};
    const susp = state.suspensions||{};
    const inj = state.injuries||{};
    const cards = state.cards||{};
    const out = rows.map(r=>{
      const ps = stats[r.player_id]||{goals:0,assists:0,cs:0,yc:0,rc:0,minutes:0,starts:0,formLast5:[]};
      const fm = ps.formLast5||[];
      const formAvg = fm.length ? (fm.reduce((a:number,b:number)=>a+b,0)/fm.length) : 0;
      const available = ( (susp[r.player_id]||0)<=0 ) && ( (inj[r.player_id]?.weeks||0)<=0 );
      const fitness = fit[r.player_id]?.fitness ?? 85;
      return {
        ...r, goals:ps.goals||0, assists:ps.assists||0, cs:ps.cs||0, yc:ps.yc||0, rc:ps.rc||0,
        minutes:ps.minutes||0, starts:ps.starts||0, formAvg: Number(formAvg.toFixed(2)), fitness: Math.round(fitness),
        suspension_left: susp[r.player_id]||0, injury_weeks: inj[r.player_id]?.weeks||0, yellow_accum: cards[r.player_id]||0,
        available
      };
    });
    return NextResponse.json({ players: out });
  }catch(e:any){
    return NextResponse.json({ error:'SQUAD_OVERVIEW_ERROR', message:e?.message }, {status:500});
  }
}
