
# Patch — Fitness Engine + Yellow Accumulation + Squad Form UI

## Fitur
- **Fitness Engine** (`lib/fitness.ts`, `configs/fitness_config.yaml`):
  - Track `playerFitness[pid] = {fitness, fatigue}`
  - Fatigue + per menit main; recovery mingguan (lebih besar kalau tidak main)
  - Multiplier risiko cedera saat fitness rendah; penalti performa → turunkan rating match
- **Yellow Accumulation** (di engine v4):
  - Map `state.cards[pid]` + threshold (default 5) → auto-suspension 1 laga + news
- **Squad Form UI**:
  - API `GET /api/squad/overview` → gabung `squads.csv` + `season_state.json` (stats, fitness, availability)
  - Page `/career/squad` + `components/SquadTable` menampilkan: G/A/CS, minutes, starts, **Form(5)**, **Fitness**, **Availability**, akumulasi YC

## Integrasi
1. Salin `configs/fitness_config.yaml` ke proyek (bisa pakai default).
2. Ganti route advance ke **V4**:
   ```ts
   import { advanceWeekWithStartersEventsV4 } from '../../../../lib/season_loop_starters_events_v4';
   const newState = await advanceWeekWithStartersEventsV4(state, process.cwd());
   ```
3. Tambahkan menu link ke `/career/squad` (jika belum ada di LeftNav).
4. Jalankan beberapa pekan → cek:
   - News: ⚽, 🟨/🟥 (dengan akumulasi & auto-ban), 🩹(*fitness mempengaruhi peluang*)
   - `/career/squad`: form rata-rata 5 laga, fitness naik-turun, availability berubah.

## Tuning
- Ubah `configs/fitness_config.yaml`:
  - `fatigue_gain_per_minute` (default 0.35)
  - `base_recovery_per_week` (20) vs `play_recovery_per_week` (8)
  - `injury_multiplier_thresholds` (fitness <60 → ×1.5; <45 → ×2.0)
  - `performance_penalty_start` (70), `performance_penalty_scale` (40)
- Ubah `discipline_rules.yaml` → `accum_threshold` untuk akumulasi YC.

## Next
- Tarik fitness ke **lineup AI** (istirahatkan pemain fitness <55)
- Tambah **form badge** di Player Profile
- Perbarui text-match engine agar menggunakan event per menit dari v4 untuk narasi
