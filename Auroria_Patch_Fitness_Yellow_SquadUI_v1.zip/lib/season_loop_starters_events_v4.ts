import { fastSimMatch } from './sim_fast';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';
import { loadSquadsCsv, pickStartingXIWithLock } from './lineup_lock';
import { loadFitnessConfig, ensureFitness, applyPostMatchFatigue, weeklyRecovery, injuryMultiplierFor, performancePenaltyFor } from './fitness';
import fs from 'fs';
import yaml from 'js-yaml';

function rand(){ return Math.random(); }
function randMinute(){ return 1 + Math.floor(Math.random()*90); }
function clamp(x:number,a:number,b:number){ return Math.max(a, Math.min(b, x)); }

type PlayerAgg = { name:string; club:string; goals:number; assists:number; cs:number; yc:number; rc:number; minutes:number; starts:number; formLast5:number[] };

function touchPS(state:any, pid:string, stub:{name:string, club:string}): PlayerAgg {
  const map = state.playerStats as Record<string, PlayerAgg>;
  map[pid] ||= { name: stub.name, club: stub.club, goals:0, assists:0, cs:0, yc:0, rc:0, minutes:0, starts:0, formLast5:[] };
  return map[pid];
}

function pushForm(ps:PlayerAgg, rating:number){
  ps.formLast5.push(rating);
  if(ps.formLast5.length>5) ps.formLast5.shift();
}

function matchRatingDelta(ev:{goals:number; assists:number; cs:boolean; yc:boolean; rc:boolean}, perfPenalty:number){
  let r = 6.5;
  r += ev.goals*0.7 + ev.assists*0.4;
  if(ev.cs) r += 0.5;
  if(ev.yc) r -= 0.2;
  if(ev.rc) r -= 1.0;
  r -= perfPenalty;
  return clamp(r, 5.0, 9.5);
}

function findDisc(d:any, event:string, key:string, def:number){
  const row = d?.table?.find((r:any)=> r.event===event);
  return row ? (row[key] ?? def) : def;
}

function pickWeighted<T extends {pos:string}>(arr:T[], weights:any){
  const bucket = arr.map(p=>({p, w: weights[p.pos as keyof typeof weights] ?? 1 }));
  const sum = bucket.reduce((a,b)=>a+b.w,0);
  let r = Math.random()*sum;
  for(const b of bucket){ r-=b.w; if(r<=0) return b.p; }
  return bucket[bucket.length-1].p;
}

export async function advanceWeekWithStartersEventsV4(state:SeasonState, root:string){
  const league:any = yaml.load(fs.readFileSync(root+'/configs/league_rules.yaml','utf-8'));
  const discipline:any = safeLoad(root+'/configs_out/discipline_rules.yaml') || safeLoad(root+'/configs/discipline_rules.yaml') || { table:[] };
  const injuryCfg:any = safeLoad(root+'/configs_out/injury_rates.yaml') || safeLoad(root+'/configs/injury_model.yaml') || {};
  const squads = loadSquadsCsv(root+'/data/squads.csv');
  const fitCfg = loadFitnessConfig(root);
  (state as any).playerStats ||= {};
  (state as any).playerFitness ||= {};
  (state as any).cards ||= {}; // yellow accumulation map: {pid: count}

  const todays = state.fixtures.filter(f=>f.week===state.week);
  const startersToday = new Set<string>();

  for(const fx of todays){
    const xiHome = pickStartingXIWithLock(fx.home, squads, state);
    const xiAway = pickStartingXIWithLock(fx.away, squads, state);
    xiHome.forEach(p=> startersToday.add(p.player_id));
    xiAway.forEach(p=> startersToday.add(p.player_id));

    // sim score
    const res = fastSimMatch(fx.home, fx.away, league);
    applyTable(state.table, fx, res);

    // accumulators
    const perfHome: Record<string,{goals:number;assists:number;yc:boolean;rc:boolean}> = {};
    const perfAway: Record<string,{goals:number;assists:number;yc:boolean;rc:boolean}> = {};

    // goals & assists
    for(let i=0;i<res.home;i++){
      const s = pickWeighted(xiHome, {FW:5,MF:3,DF:2,GK:1});
      const a = pickWeighted(xiHome.filter(p=>p.player_id!==s.player_id), {MF:5,FW:3,DF:2,GK:1});
      touchPS(state, s.player_id, {name:s.name, club:fx.home}).goals++;
      perfHome[s.player_id] ||= {goals:0,assists:0,yc:false,rc:false}; perfHome[s.player_id].goals++;
      if(a){ touchPS(state, a.player_id, {name:a.name, club:fx.home}).assists++; perfHome[a.player_id] ||= {goals:0,assists:0,yc:false,rc:false}; perfHome[a.player_id].assists++; }
      state.news.push({t:new Date().toISOString(), msg:`⚽ ${fx.home}: ${s.name} ${randMinute()}'${a?` (assist ${a.name})`:''}`, tags:['goal','scorer']});
    }
    for(let i=0;i<res.away;i++){
      const s = pickWeighted(xiAway, {FW:5,MF:3,DF:2,GK:1});
      const a = pickWeighted(xiAway.filter(p=>p.player_id!==s.player_id), {MF:5,FW:3,DF:2,GK:1});
      touchPS(state, s.player_id, {name:s.name, club:fx.away}).goals++;
      perfAway[s.player_id] ||= {goals:0,assists:0,yc:false,rc:false}; perfAway[s.player_id].goals++;
      if(a){ touchPS(state, a.player_id, {name:a.name, club:fx.away}).assists++; perfAway[a.player_id] ||= {goals:0,assists:0,yc:false,rc:false}; perfAway[a.player_id].assists++; }
      state.news.push({t:new Date().toISOString(), msg:`⚽ ${fx.away}: ${s.name} ${randMinute()}'${a?` (assist ${a.name})`:''}`, tags:['goal','scorer']});
    }

    // clean sheets
    if(res.away===0){ const gk = xiHome.find(p=>p.pos==='GK') || xiHome[0]; touchPS(state, gk.player_id, {name:gk.name, club:fx.home}).cs++; }
    if(res.home===0){ const gk = xiAway.find(p=>p.pos==='GK') || xiAway[0]; touchPS(state, gk.player_id, {name:gk.name, club:fx.away}).cs++; }

    // discipline with accumulation
    const yProb = Number(findDisc(discipline,'foul_caution','yellow_prob',0.18));
    const rProb = Number(findDisc(discipline,'foul_serious','red_prob',0.02));
    const banMatches = Number(findDisc(discipline,'foul_serious','ban_matches',1));
    const accumThr = Number(discipline?.accum_threshold ?? 5);

    // home
    if(rand()<yProb){
      const p = randomFrom(xiHome);
      touchPS(state, p.player_id, {name:p.name, club:fx.home}).yc++;
      state.cards[p.player_id] = (state.cards[p.player_id]||0) + 1;
      state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.home}: ${p.name}`, tags:['discipline']});
      if(state.cards[p.player_id] >= accumThr){
        state.suspensions[p.player_id] = (state.suspensions[p.player_id]||0) + 1;
        state.cards[p.player_id] = 0; // reset
        state.news.push({t:new Date().toISOString(), msg:`⛔ Suspension (yellow accumulation): ${p.name} — 1 match`, tags:['discipline']});
      }
    }
    if(rand()<rProb){
      const p = randomFrom(xiHome);
      touchPS(state, p.player_id, {name:p.name, club:fx.home}).rc++;
      state.suspensions[p.player_id] = (state.suspensions[p.player_id]||0) + banMatches;
      state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.home}: ${p.name} (ban ${banMatches})`, tags:['discipline']});
    }

    // away
    if(rand()<yProb){
      const p = randomFrom(xiAway);
      touchPS(state, p.player_id, {name:p.name, club:fx.away}).yc++;
      state.cards[p.player_id] = (state.cards[p.player_id]||0) + 1;
      state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.away}: ${p.name}`, tags:['discipline']});
      if(state.cards[p.player_id] >= accumThr){
        state.suspensions[p.player_id] = (state.suspensions[p.player_id]||0) + 1;
        state.cards[p.player_id] = 0;
        state.news.push({t:new Date().toISOString(), msg:`⛔ Suspension (yellow accumulation): ${p.name} — 1 match`, tags:['discipline']});
      }
    }
    if(rand()<rProb){
      const p = randomFrom(xiAway);
      touchPS(state, p.player_id, {name:p.name, club:fx.away}).rc++;
      state.suspensions[p.player_id] = (state.suspensions[p.player_id]||0) + banMatches;
      state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.away}: ${p.name} (ban ${banMatches})`, tags:['discipline']});
    }

    // injuries (fitness multiplier)
    const baseRate = Number(injuryCfg?.rate_per_match ?? 0.07);
    const targetTeam = rand()<0.5 ? {xi:xiHome, club:fx.home} : {xi:xiAway, club:fx.away};
    const candidate = randomFrom(targetTeam.xi);
    const mult = injuryMultiplierFor(candidate.player_id, state.playerFitness, fitCfg);
    if(rand() < baseRate * mult){
      const minorP = Number(injuryCfg?.severity_split?.minor ?? 0.6);
      const modP   = Number(injuryCfg?.severity_split?.moderate ?? 0.3);
      const serP   = Number(injuryCfg?.severity_split?.serious ?? 0.1);
      const r = rand(); let kind = 'minor';
      if(r>minorP) kind='moderate';
      if(r>(minorP+modP)) kind='serious';
      const range = injuryCfg?.durations_weeks?.[kind] ?? [1,2];
      const weeks = Math.max(range[0], Math.min(range[1], Math.floor(range[0] + rand()*(range[1]-range[0]+1))));
      state.injuries[candidate.player_id] = {weeks};
      state.news.push({t:new Date().toISOString(), msg:`🩹 Injury: ${candidate.name} (${weeks}w, ${kind})`, tags:['injury']});
    }

    // minutes & starts & form + fatigue application
    const redExitMinute = 45 + Math.floor(Math.random()*40);
    for(const p of xiHome){
      const perf = perfHome[p.player_id] || {goals:0,assists:0,yc:false,rc:false};
      const mins = perf.rc ? redExitMinute : 90;
      touchPS(state, p.player_id, {name:p.name, club:fx.home}).starts += 1;
      touchPS(state, p.player_id, {name:p.name, club:fx.home}).minutes += mins;
      // fitness penalty affects rating
      const penalty = performancePenaltyFor(p.player_id, state.playerFitness, fitCfg);
      const rating = matchRatingDelta({goals:perf.goals,assists:perf.assists,cs:(res.away===0 && p.pos==='GK'),yc:perf.yc,rc:perf.rc}, penalty);
      pushForm(touchPS(state, p.player_id, {name:p.name, club:fx.home}), rating);
      applyPostMatchFatigue(state.playerFitness, p.player_id, mins, fitCfg);
    }
    for(const p of xiAway){
      const perf = perfAway[p.player_id] || {goals:0,assists:0,yc:false,rc:false};
      const mins = perf.rc ? redExitMinute : 90;
      touchPS(state, p.player_id, {name:p.name, club:fx.away}).starts += 1;
      touchPS(state, p.player_id, {name:p.name, club:fx.away}).minutes += mins;
      const penalty = performancePenaltyFor(p.player_id, state.playerFitness, fitCfg);
      const rating = matchRatingDelta({goals:perf.goals,assists:perf.assists,cs:(res.home===0 && p.pos==='GK'),yc:perf.yc,rc:perf.rc}, penalty);
      pushForm(touchPS(state, p.player_id, {name:p.name, club:fx.away}), rating);
      applyPostMatchFatigue(state.playerFitness, p.player_id, mins, fitCfg);
    }

    // final result
    state.news.push({t:new Date().toISOString(), msg:`Result — ${fx.home} ${res.home}-${res.away} ${fx.away}`, tags:['result']});
  }

  // weekly recovery
  weeklyRecovery(state.playerFitness, startersToday, fitCfg);

  // decay suspensions/injuries
  Object.keys(state.suspensions).forEach(pid=> state.suspensions[pid] = Math.max(0,(state.suspensions[pid]-1)));
  Object.keys(state.injuries).forEach(pid=> state.injuries[pid].weeks = Math.max(0,(state.injuries[pid].weeks-1)));
  state.week += 1; return state;
}

function randomFrom<T>(arr:T[]):T{ return arr[Math.floor(Math.random()*arr.length)]; }
function safeLoad(path:string){ try{ return yaml.load(fs.readFileSync(path,'utf-8')); }catch{ return null; } }
