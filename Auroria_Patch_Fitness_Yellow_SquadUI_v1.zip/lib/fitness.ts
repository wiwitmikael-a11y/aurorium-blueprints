import fs from 'fs';
import yaml from 'js-yaml';

export type FitnessMap = Record<string,{ fitness:number, fatigue:number }>;

export function loadFitnessConfig(root:string){
  try{
    const p = root + '/configs/fitness_config.yaml';
    return yaml.load(fs.readFileSync(p,'utf-8')) as any;
  }catch{ return {
    base_recovery_per_week: 20, play_recovery_per_week: 8, fatigue_gain_per_minute: 0.35,
    injury_multiplier_thresholds: [{lt:45,mult:2.0},{lt:60,mult:1.5}],
    performance_penalty_start: 70, performance_penalty_scale: 40
  }; }
}

export function ensureFitness(state:any){
  (state as any).playerFitness ||= {};
  return state.playerFitness as FitnessMap;
}

export function applyPostMatchFatigue(fitness:FitnessMap, pid:string, minutes:number, cfg:any){
  const rec = fitness[pid] ||= { fitness: 85, fatigue: 15 };
  rec.fatigue = clamp(rec.fatigue + minutes * (cfg.fatigue_gain_per_minute ?? 0.35), 0, 100);
  rec.fitness = clamp(100 - rec.fatigue, 0, 100);
}

export function weeklyRecovery(fitness:FitnessMap, starters:Set<string>, cfg:any){
  for(const pid of Object.keys(fitness)){
    const rec = fitness[pid];
    const played = starters.has(pid);
    const gain = played ? (cfg.play_recovery_per_week ?? 8) : (cfg.base_recovery_per_week ?? 20);
    rec.fatigue = clamp(rec.fatigue - gain, 0, 100);
    rec.fitness = clamp(100 - rec.fatigue, 0, 100);
  }
}

export function injuryMultiplierFor(pid:string, fitness:FitnessMap, cfg:any){
  const f = (fitness[pid]?.fitness ?? 85);
  const thrs = cfg.injury_multiplier_thresholds || [];
  for(const t of thrs){
    if(f < t.lt) return t.mult;
  }
  return 1.0;
}

export function performancePenaltyFor(pid:string, fitness:FitnessMap, cfg:any){
  const f = (fitness[pid]?.fitness ?? 85);
  const start = cfg.performance_penalty_start ?? 70;
  const scale = cfg.performance_penalty_scale ?? 40;
  if(f >= start) return 0;
  return Math.max(0, (start - f) / scale); // ~0..1
}

function clamp(x:number,a:number,b:number){ return Math.max(a, Math.min(b, x)); }
