'use client';
type Row = {
  club:string; player_id:string; name:string; pos:string; ovr:number; goals:number; assists:number; cs:number;
  minutes:number; starts:number; formAvg:number; fitness:number; available:boolean;
  suspension_left:number; injury_weeks:number; yellow_accum:number; yc:number; rc:number;
};
const POS_ORDER:any = {GK:0,DF:1,MF:2,FW:3};
export function SquadTable({rows}:{rows:Row[]}){
  const sorted = rows.slice().sort((a,b)=> a.club.localeCompare(b.club) || POS_ORDER[a.pos]-POS_ORDER[b.pos] || b.ovr-a.ovr);
  return (<table className="table text-sm">
    <thead>
      <tr><th>Club</th><th>Player</th><th>Pos</th><th>OVR</th><th>G</th><th>A</th><th>CS</th><th>Min</th><th>Starts</th><th>Form</th><th>Fit</th><th>Avail</th><th>Sus</th><th>Inj</th><th>YC</th></tr>
    </thead>
    <tbody>
      {sorted.map((r,i)=>(<tr key={r.player_id}>
        <td>{r.club}</td>
        <td>{r.name}</td>
        <td>{r.pos}</td>
        <td>{r.ovr}</td>
        <td>{r.goals}</td>
        <td>{r.assists}</td>
        <td>{r.cs}</td>
        <td>{r.minutes}</td>
        <td>{r.starts}</td>
        <td>{r.formAvg? r.formAvg.toFixed(2): '-'}</td>
        <td>{r.fitness}</td>
        <td>{r.available ? '✓' : '✕'}</td>
        <td>{r.suspension_left||'-'}</td>
        <td>{r.injury_weeks||'-'}</td>
        <td>{r.yellow_accum||0}</td>
      </tr>))}
    </tbody>
  </table>);
}
