# Auroria Economy v2 (Single-Currency AC) — Add-on Pack
Generated: 2025-09-05T09:15:53.486165Z

Use alongside AuroriaDB_v1.
- schema: finance structures
- config: tuning params
- seed: sample club finance, contracts, ledger
