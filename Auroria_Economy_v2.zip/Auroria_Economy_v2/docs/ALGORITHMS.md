# Economy Algorithms (Essentials)
- Attendance & Ticketing
- Wages & Bonuses
- Sponsor Payouts
- FairPlay Checks
- Inflation
- Loans
- Taxes
