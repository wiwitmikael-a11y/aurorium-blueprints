
# Patch — Match Events with Starters + Assists & Clean Sheets

## What’s inside
- **Starting XI selection (4-4-2)** from `data/squads.csv` based on OVR per posisi.
- Goals now assigned to **real starters**; assists chosen dari rekan XI (MF bias).
- **Clean sheets** awarded to GK yang kebobolan 0.
- Cards & injuries ditetapkan ke **starter** (bukan AUTO).
- `state.playerStats` menyimpan agregat: `{goals, assists, cs, yc, rc}` per player_id.
- API & UI baru:
  - `/api/stats/assists` → `components/TopAssists` → `/career/competitions/assists`
  - `/api/stats/cleansheets` → `components/TopCleanSheets` → `/career/competitions/cleansheets`

## How to wire
1. Copy folder dalam patch ke proyek (merge ke `lib/`, `app/`, `components/`).  
2. Ubah route advance (jika ingin langsung gunakan engine baru):
   - Panggil `advanceWeekWithStartersEvents(state, process.cwd())` **sebagai pengganti** advance sebelumnya.
   - Atau manfaatkan patch advance yang sudah ada (discipline+scorers) → upgrade sesuai preferensi.
3. Pastikan `data/squads.csv` berisi kolom: `club_id,player_id,name,pos,ovr,...`

## Next ideas
- Track **minutes played** & **starting appearances** untuk rating form.  
- Tambah **assist secondaries** untuk build-up panjang (opsional).  
- Hook ke **match text-engine** untuk kronologi event yang lebih detail.
