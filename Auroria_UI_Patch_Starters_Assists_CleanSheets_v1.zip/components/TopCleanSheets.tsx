'use client';
type Row = {player_id:string, name:string, club:string, cs:number};
export function TopCleanSheets({rows}:{rows:Row[]}){
  return (<table className="table text-sm">
    <thead><tr><th>#</th><th>Goalkeeper</th><th>Club</th><th>Clean Sheets</th></tr></thead>
    <tbody>{rows.map((r,i)=>(<tr key={r.player_id}><td>{i+1}</td><td>{r.name}</td><td>{r.club}</td><td>{r.cs}</td></tr>))}</tbody>
  </table>);
}
