'use client';
type Row = {player_id:string, name:string, club:string, assists:number};
export function TopAssists({rows}:{rows:Row[]}){
  return (<table className="table text-sm">
    <thead><tr><th>#</th><th>Player</th><th>Club</th><th>Assists</th></tr></thead>
    <tbody>{rows.map((r,i)=>(<tr key={r.player_id}><td>{i+1}</td><td>{r.name}</td><td>{r.club}</td><td>{r.assists}</td></tr>))}</tbody>
  </table>);
}
