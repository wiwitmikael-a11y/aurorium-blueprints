import type { Player } from './lineup';

function randChoice<T>(arr:T[]):T{ return arr[Math.floor(Math.random()*arr.length)]; }

export function pickGoalScorerFromXI(xi:Player){
  // not used
  return xi;
}

export function pickScorerFromXI(xi:Player[]){
  // weight by position
  const bucket = xi.map(p=>({ p, w: p.pos==='FW'?5:p.pos==='MF'?3:p.pos==='DF'?2:1 }));
  const sum = bucket.reduce((a,b)=>a+b.w,0);
  let r = Math.random()*sum;
  for(const b of bucket){ r-=b.w; if(r<=0) return b.p; }
  return bucket[bucket.length-1].p;
}

export function pickAssisterFromXI(xi:Player[], scorerId:string){
  const others = xi.filter(p=>p.player_id!==scorerId);
  if(others.length===0) return null;
  const bucket = others.map(p=>({ p, w: p.pos==='MF'?5:p.pos==='FW'?3:2 }));
  const sum = bucket.reduce((a,b)=>a+b.w,0);
  let r = Math.random()*sum;
  for(const b of bucket){ r-=b.w; if(r<=0) return b.p; }
  return bucket[bucket.length-1].p;
}
