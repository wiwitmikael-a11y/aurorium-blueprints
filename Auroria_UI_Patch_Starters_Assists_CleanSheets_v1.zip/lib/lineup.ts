import fs from 'fs';

export type Player = { player_id:string; name:string; pos:'GK'|'DF'|'MF'|'FW'; ovr:number };
export type SquadsMap = Record<string, Player[]>;

export function loadSquadsCsv(csvPath:string): SquadsMap {
  const txt = fs.readFileSync(csvPath,'utf-8').trim();
  const lines = txt.split(/\r?\n/);
  const hdr = lines.shift()?.split(',')||[];
  const idx:Record<string,number> = {}; hdr.forEach((h,i)=> idx[h]=i);
  const map: SquadsMap = {};
  for(const l of lines){
    const cols = l.split(',');
    const club = cols[idx['club_id']];
    const player_id = cols[idx['player_id']];
    const name = cols[idx['name']];
    const pos = cols[idx['pos']] as any;
    const ovr = Number(cols[idx['ovr']]);
    (map[club] ||= []).push({player_id, name, pos, ovr});
  }
  return map;
}

// Simple 4-4-2: 1 GK, 4 DF, 4 MF, 2 FW (fallback if kurang)
// Choose top OVR per posisi; jika kurang, isi dari posisi terdekat yang tersisa.
export function pickStartingXI(clubId:string, squads:SquadsMap){
  const pool = (squads[clubId]||[]).slice().sort((a,b)=> b.ovr-a.ovr);
  const byPos = { GK: pool.filter(p=>p.pos==='GK'),
                  DF: pool.filter(p=>p.pos==='DF'),
                  MF: pool.filter(p=>p.pos==='MF'),
                  FW: pool.filter(p=>p.pos==='FW') };
  const need = { GK:1, DF:4, MF:4, FW:2 };
  const xi: Player[] = [];
  (['GK','DF','MF','FW'] as const).forEach(pos=>{
    xi.push(...byPos[pos].slice(0, need[pos]));
  });
  // filler jika kurang dari 11
  const chosenIds = new Set(xi.map(p=>p.player_id));
  for(const p of pool){
    if(xi.length>=11) break;
    if(!chosenIds.has(p.player_id)){ xi.push(p); chosenIds.add(p.player_id); }
  }
  return xi.slice(0,11);
}
