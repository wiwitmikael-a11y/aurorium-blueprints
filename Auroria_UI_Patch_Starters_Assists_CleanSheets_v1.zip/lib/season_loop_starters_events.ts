import { fastSimMatch } from './sim_fast';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';
import { loadSquadsCsv, pickStartingXI } from './lineup';
import { pickScorerFromXI, pickAssisterFromXI } from './scoring_ex';
import fs from 'fs';
import yaml from 'js-yaml';

function rand(){ return Math.random(); }
function randMinute(){ return 1 + Math.floor(Math.random()*90); }

type PlayerStats = { name:string; club:string; goals:number; assists:number; cs:number; yc:number; rc:number; injured_weeks?:number };

export async function advanceWeekWithStartersEvents(state:SeasonState, root:string){
  // load configs & squads once per call
  const league:any = yaml.load(fs.readFileSync(root+'/configs/league_rules.yaml','utf-8'));
  const discipline:any = safeLoad(root+'/configs_out/discipline_rules.yaml') || safeLoad(root+'/configs/discipline_rules.yaml') || { table:[] };
  const injury:any = safeLoad(root+'/configs_out/injury_rates.yaml') || safeLoad(root+'/configs/injury_model.yaml') || {};
  const squads = loadSquadsCsv(root+'/data/squads.csv');

  // ensure containers
  (state as any).playerStats ||= {}; // {pid: PlayerStats}

  const todays = state.fixtures.filter(f=>f.week===state.week);
  for(const fx of todays){
    // XI
    const xiHome = pickStartingXI(fx.home, squads);
    const xiAway = pickStartingXI(fx.away, squads);

    // sim
    const res = fastSimMatch(fx.home, fx.away, league);
    applyTable(state.table, fx, res);

    // goals & assists
    for(let i=0;i<res.home;i++){
      const s = pickScorerFromXI(xiHome);
      const a = pickAssisterFromXI(xiHome, s.player_id);
      touchPS(state, s, { club: fx.home }).goals++;
      if(a) touchPS(state, a, { club: fx.home }).assists++;
      const assistText = a ? ` (assist ${a.name})` : '';
      state.news.push({t:new Date().toISOString(), msg:`⚽ ${fx.home}: ${s.name} ${randMinute()}'${assistText}`, tags:['goal','scorer']});
    }
    for(let i=0;i<res.away;i++){
      const s = pickScorerFromXI(xiAway);
      const a = pickAssisterFromXI(xiAway, s.player_id);
      touchPS(state, s, { club: fx.away }).goals++;
      if(a) touchPS(state, a, { club: fx.away }).assists++;
      const assistText = a ? ` (assist ${a.name})` : '';
      state.news.push({t:new Date().toISOString(), msg:`⚽ ${fx.away}: ${s.name} ${randMinute()}'${assistText}`, tags:['goal','scorer']});
    }
    state.news.push({t:new Date().toISOString(), msg:`Result — ${fx.home} ${res.home}-${res.away} ${fx.away}`, tags:['result']});

    // clean sheets for GK
    if(res.away===0){ const gk = xiHome.find(p=>p.pos==='GK') || xiHome[0]; touchPS(state, gk, {club:fx.home}).cs++; }
    if(res.home===0){ const gk = xiAway.find(p=>p.pos==='GK') || xiAway[0]; touchPS(state, gk, {club:fx.away}).cs++; }

    // discipline events → assign to starters
    const yProb = Number(findDisc(discipline,'foul_caution','yellow_prob',0.18));
    const rProb = Number(findDisc(discipline,'foul_serious','red_prob',0.02));
    const banMatches = Number(findDisc(discipline,'foul_serious','ban_matches',1));
    // home
    if(rand()<yProb){ const p = randomFrom(xiHome); touchPS(state, p, {club:fx.home}).yc++; state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.home}: ${p.name}`, tags:['discipline']}); }
    if(rand()<rProb){ const p = randomFrom(xiHome); touchPS(state, p, {club:fx.home}).rc++; state.suspensions[p.player_id] = banMatches; state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.home}: ${p.name} (ban ${banMatches})`, tags:['discipline']}); }
    // away
    if(rand()<yProb){ const p = randomFrom(xiAway); touchPS(state, p, {club:fx.away}).yc++; state.news.push({t:new Date().toISOString(), msg:`🟨 ${fx.away}: ${p.name}`, tags:['discipline']}); }
    if(rand()<rProb){ const p = randomFrom(xiAway); touchPS(state, p, {club:fx.away}).rc++; state.suspensions[p.player_id] = banMatches; state.news.push({t:new Date().toISOString(), msg:`🟥 ${fx.away}: ${p.name} (ban ${banMatches})`, tags:['discipline']}); }

    // injuries → assign to starters
    const minorP = Number(injury?.severity_split?.minor ?? 0.6);
    const modP   = Number(injury?.severity_split?.moderate ?? 0.3);
    const serP   = Number(injury?.severity_split?.serious ?? 0.1);
    const rate   = Number(injury?.rate_per_match ?? 0.07);
    if(rand()<rate){
      const p = randomFrom(rand()<0.5?xiHome:xiAway);
      const r = rand(); let kind = 'minor';
      if(r>minorP) kind='moderate';
      if(r>(minorP+modP)) kind='serious';
      const range = injury?.durations_weeks?.[kind] ?? [1,2];
      const weeks = Math.max(range[0], Math.min(range[1], Math.floor(range[0] + rand()*(range[1]-range[0]+1))));
      state.injuries[p.player_id] = {weeks};
      touchPS(state, p, {club:p ? (p as any).club : ''}).injured_weeks = weeks;
      state.news.push({t:new Date().toISOString(), msg:`🩹 Injury: ${p.name} (${weeks}w, ${kind})`, tags:['injury']});
    }
  }

  // decay
  Object.keys(state.suspensions).forEach(pid=> state.suspensions[pid] = Math.max(0,(state.suspensions[pid]-1)));
  Object.keys(state.injuries).forEach(pid=> state.injuries[pid].weeks = Math.max(0,(state.injuries[pid].weeks-1)));
  state.week += 1; return state;
}

function randomFrom<T>(arr:T[]):T{ return arr[Math.floor(Math.random()*arr.length)]; }
function findDisc(d:any, event:string, key:string, def:number){
  const row = d?.table?.find((r:any)=> r.event===event);
  return row ? (row[key] ?? def) : def;
}
function touchPS(state:any, player:any, meta:{club:string}): any {
  const map = state.playerStats as Record<string, any>;
  map[player.player_id] ||= { name: player.name, club: meta.club, goals:0, assists:0, cs:0, yc:0, rc:0 };
  return map[player.player_id];
}
function safeLoad(path:string){ try{ return yaml.load(fs.readFileSync(path,'utf-8')); }catch{ return null; } }
