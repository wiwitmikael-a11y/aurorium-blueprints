import Shell from '../../../../components/Shell';
import { TopAssists } from '../../../../components/TopAssists';
async function getData(){ const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/stats/assists', { cache:'no-store' }); return r.json(); }
async function getState(){ const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/season/state', { cache:'no-store' }); return r.json(); }
export default async function Page(){
  const [data,state] = await Promise.all([getData(), getState()]);
  return (<Shell week={state.week}>
    <h1 className="text-xl mb-2">Top Assists</h1>
    <div className="panel"><TopAssists rows={data.top}/></div>
  </Shell>);
}
