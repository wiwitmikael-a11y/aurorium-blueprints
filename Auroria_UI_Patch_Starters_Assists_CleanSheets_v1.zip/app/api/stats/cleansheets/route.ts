import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
export async function GET(){
  try{
    const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
    const map = state.playerStats || {};
    const rows = Object.entries(map).map(([pid, v]:any)=>({ player_id:pid, ...v }))
      .filter((r:any)=> r.pos==='GK' ? true : true) // we didn't store pos; rely on cs>0
      .sort((a:any,b:any)=> b.cs-a.cs).slice(0,50);
    return NextResponse.json({ top: rows });
  }catch(e:any){
    return NextResponse.json({ error:'CS_ERROR', message:e?.message }, {status:500});
  }
}
