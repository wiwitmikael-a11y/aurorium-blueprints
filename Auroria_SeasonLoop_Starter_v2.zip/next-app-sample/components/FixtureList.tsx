'use client';
import React from 'react';
export function FixtureList({items}:{items:{week:number,home:string,away:string,kickoff?:string}[]}){
  return (<div className="space-y-2">
    {items.map((fx,i)=>(<div key={i} className="p-2 border border-neutral-700 rounded">
      <b>W{fx.week}</b> — {fx.home} vs {fx.away} <span className="opacity-70">{fx.kickoff||''}</span>
    </div>))}
  </div>);
}
