'use client';
import React from 'react';
export function NewsFeed({items}:{items:{t:string,msg:string}[]}){
  return (<div className="space-y-2">
    {items.map((n,i)=>(<div key={i} className="p-2 border border-neutral-700 rounded"><span className="opacity-60">{new Date(n.t).toLocaleString()}</span> — {n.msg}</div>))}
  </div>);
}
