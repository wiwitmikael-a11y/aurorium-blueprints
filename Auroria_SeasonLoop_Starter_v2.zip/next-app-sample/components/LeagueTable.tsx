'use client';
import React from 'react';
export function LeagueTable({rows}:{rows:{club:string, pts:number, gf:number, ga:number, gd:number, w:number, d:number, l:number}[]}){
  return (<table className="w-full text-sm">
    <thead><tr><th>#</th><th>Club</th><th>Pts</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>GD</th></tr></thead>
    <tbody>{rows.map((r,i)=>(<tr key={r.club}><td>{i+1}</td><td>{r.club}</td><td>{r.pts}</td><td>{r.w}</td><td>{r.d}</td><td>{r.l}</td><td>{r.gf}</td><td>{r.ga}</td><td>{r.gd}</td></tr>))}</tbody>
  </table>);
}
