import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
export async function GET(){ const json = await readFile(process.cwd()+'/data/season_state.json','utf-8'); return NextResponse.json(JSON.parse(json)); }
