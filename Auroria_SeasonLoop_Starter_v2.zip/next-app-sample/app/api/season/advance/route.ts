import { NextResponse } from 'next/server';
import { readFile, writeFile } from 'fs/promises';
import { advanceWeek } from '../../../../lib/season_loop';
import yaml from 'js-yaml';

export async function POST(){
  const statePath = process.cwd()+'/data/season_state.json';
  const rules = yaml.load(await readFile(process.cwd()+'/configs/league_rules.yaml','utf-8'));
  const state = JSON.parse(await readFile(statePath,'utf-8'));
  const newState = await advanceWeek(state, rules);
  await writeFile(statePath, JSON.stringify(newState,null,2), 'utf-8');
  return NextResponse.json({ ok:true, week:newState.week });
}
