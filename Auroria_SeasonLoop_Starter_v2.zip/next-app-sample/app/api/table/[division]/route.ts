import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
export async function GET(_:Request, ctx:{params:{division:string}}){
  const state = JSON.parse(await readFile(process.cwd()+'/data/season_state.json','utf-8'));
  const table = Object.entries(state.table).map(([club,row]:any)=>({club, ...row}))
    .sort((a:any,b:any)=> b.pts-a.pts || b.gd-a.gd || b.gf-a.gf);
  return NextResponse.json({ division: ctx.params.division, table });
}
