export const dynamic = 'force-dynamic';
async function getState(){
  const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/season/state', { cache:'no-store' });
  return r.json();
}
export default async function Page(){
  const state = await getState();
  return (<main className="p-6">
    <h1 className="text-xl mb-4">News</h1>
    <div className="space-y-2">
      {state.news.slice().reverse().map((n:any,i:number)=>(<div key={i} className="p-2 border border-neutral-700 rounded">
        <span className="opacity-60">{new Date(n.t).toLocaleString()}</span> — {n.msg}
      </div>))}
    </div>
  </main>);
}
