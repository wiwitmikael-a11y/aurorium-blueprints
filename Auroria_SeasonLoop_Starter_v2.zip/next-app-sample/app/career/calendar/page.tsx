export const dynamic = 'force-dynamic';
async function getState(){
  const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/season/state', { cache:'no-store' });
  return r.json();
}
export default async function Page(){
  const state = await getState();
  const todays = state.fixtures.filter((f:any)=> f.week===state.week);
  return (<main className="p-6">
    <h1 className="text-xl mb-2">Week {state.week} — Fixtures</h1>
    <form action={async()=>{await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/season/advance',{method:'POST'});}}>
      <button className="px-3 py-2 border rounded mb-4">Advance Week</button>
    </form>
    <div className="space-y-2">
      {todays.map((fx:any,i:number)=>(<div key={i} className="p-2 border border-neutral-700 rounded">{fx.home} vs {fx.away} — {fx.kickoff}</div>))}
    </div>
  </main>);
}
