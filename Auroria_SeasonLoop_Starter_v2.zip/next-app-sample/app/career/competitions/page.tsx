import { LeagueTable } from '../../../components/LeagueTable';
export const dynamic = 'force-dynamic';
async function getTable(){
  const r = await fetch(process.env.NEXT_PUBLIC_BASE_URL + '/api/table/APL', { cache:'no-store' });
  return r.json();
}
export default async function Page(){
  const data = await getTable();
  return (<main className="p-6">
    <h1 className="text-xl mb-4">Arcadia Premier League — Standings</h1>
    <LeagueTable rows={data.table}/>
  </main>);
}
