Auroria Season Loop & AI Clubs — Starter v2
==========================================

Folder:
- configs/  → YAML rules & models
- data/     → clubs.csv, squads.csv, fixtures.csv, season_state.json
- lib/      → TS libs (scheduling, sim_fast, season_loop, types)
- next-app-sample/ → contoh API & UI (App Router)

Langkah cepat (Next.js):
1) Copy `configs/` dan `data/` ke root proyek Next.js (buat folder sama).
2) Salin `lib/*.ts` ke `lib/` proyek lo.
3) Salin `next-app-sample/app/api/**` dan `next-app-sample/components/**` serta `next-app-sample/app/career/**` ke proyek.
4) Set env `NEXT_PUBLIC_BASE_URL=http://localhost:3000` (dev) di `.env.local`.
5) Jalankan `npm run dev` → buka `/career/competitions`, `/career/calendar`, `/career/news`.
6) Klik **Advance Week** → fast-sim jalan, tabel & news ter-update.

Catatan:
- `data/season_state.json` sudah di-seed dengan 20 klub APL dan fixtures 38 pekan (home/away).
- Model fast-sim masih placeholder rating; sambungkan ke squads.csv untuk rating akurat.
- Semua angka utama dapat di-tune via YAML; gunakan hot-reload saat dev.

Next:
- Implementasikan transfer AI & tactical triggers (lihat `configs/ai_club_policies.yaml`).
- Hook suspensions/injuries ke decay & blocking lineup.
- Tambahkan endpoint untuk standings detail dan top-scorers (analitik).
