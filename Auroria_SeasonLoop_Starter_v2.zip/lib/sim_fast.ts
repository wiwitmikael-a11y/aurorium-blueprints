function teamRating(teamId:string):number{
  // TODO: compute from squads; placeholder
  return 0.8 + Math.random()*0.4;
}
function poisson(lambda:number){
  let L = Math.exp(-lambda), k=0, p=1;
  do{ k++; p*=Math.random(); }while(p>L);
  return k-1;
}
export function fastSimMatch(homeId:string, awayId:string, rules:any){
  const homeAdv = rules?.home_advantage ?? 0.12;
  const rHome = teamRating(homeId) + homeAdv;
  const rAway = teamRating(awayId);
  const lamHome = Math.max(0.3, 1.25 + (rHome - rAway));
  const lamAway = Math.max(0.2, 1.05 + (rAway - rHome));
  return {home:poisson(lamHome), away:poisson(lamAway)};
}
