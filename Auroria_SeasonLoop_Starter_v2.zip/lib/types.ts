export type ClubId = string;
export interface TableRow { pts:number; gf:number; ga:number; gd:number; w:number; d:number; l:number; }
export interface Fixture { week:number; home:ClubId; away:ClubId; kickoff?:string; stadium?:string; cup_id?:string; }
export interface SeasonState {
  meta:{season:string; division:string};
  week:number;
  table:Record<ClubId, TableRow>;
  fixtures:Fixture[];
  suspensions:Record<string, number>;
  injuries:Record<string, {weeks:number}>;
  news:{t:string; msg:string; tags?:string[]}[];
}
