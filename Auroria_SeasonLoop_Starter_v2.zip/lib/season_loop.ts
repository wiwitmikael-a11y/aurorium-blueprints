import { fastSimMatch } from './sim_fast';
import { applyTable } from './scheduling';
import type { SeasonState } from './types';

export async function advanceWeek(state:SeasonState, rules:any){
  const todays = state.fixtures.filter(f=>f.week===state.week);
  for(const fx of todays){
    const res = fastSimMatch(fx.home, fx.away, rules);
    applyTable(state.table, fx, res);
    state.news.push({t:new Date().toISOString(), msg:`${fx.home} ${res.home}-${res.away} ${fx.away}`, tags:['result']});
  }
  Object.keys(state.suspensions).forEach(pid=> state.suspensions[pid] = Math.max(0,(state.suspensions[pid]-1)));
  Object.keys(state.injuries).forEach(pid=> state.injuries[pid].weeks = Math.max(0,(state.injuries[pid].weeks-1)));
  state.week += 1; return state;
}
