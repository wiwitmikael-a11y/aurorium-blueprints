export function makeFixtures(teams:string[], rounds=2){
  const arr = teams.slice(); if(arr.length%2===1) arr.push('BYE');
  const n = arr.length, half = n/2; const out:any[] = [];
  for(let r=0;r<(n-1)*rounds;r++){
    const week = r+1;
    for(let i=0;i<half;i++){
      let home = arr[i], away = arr[n-1-i];
      if(home!=='BYE' && away!=='BYE'){
        if(r>=(n-1)) [home,away] = [away,home];
        out.push({week, home, away});
      }
    }
    const fixed = arr[0], rest = arr.slice(1);
    rest.unshift(rest.pop() as string);
    arr.splice(0, arr.length, fixed, ...rest);
  }
  return out;
}
export function applyTable(table:any, fx:{home:string,away:string}, res:{home:number,away:number}){
  const th = table[fx.home] ||= {pts:0,gf:0,ga:0,gd:0,w:0,d:0,l:0};
  const ta = table[fx.away] ||= {pts:0,gf:0,ga:0,gd:0,w:0,d:0,l:0};
  th.gf+=res.home; th.ga+=res.away; th.gd = th.gf-th.ga;
  ta.gf+=res.away; ta.ga+=res.home; ta.gd = ta.gf-ta.ga;
  if(res.home>res.away){ th.w++; th.pts+=3; ta.l++; }
  else if(res.home<res.away){ ta.w++; ta.pts+=3; th.l++; }
  else { th.d++; ta.d++; th.pts++; ta.pts++; }
}
