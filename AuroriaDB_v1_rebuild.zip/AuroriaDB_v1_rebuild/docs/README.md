# AuroriaDB v1 Rebuild
Includes schemas, nations, clubs, synergy rules, name pools, sample players, and mass seed 10k players (5x2000).

Added club for Aevia: Aevia Sylvan Guard (Grove Arena).
