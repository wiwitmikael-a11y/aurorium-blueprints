
# Auroria DB v1 (Steampunk Medieval Magicka Football Manager)

Generated: 2025-09-04T20:12:37.027264Z

## Struktur
- schema/: JSON Schemas (player, club, nation, synergy)
- data/  :
  - nations.yaml, clubs.yaml, synergy_rules.yaml, name_pools.yaml
- sample_generated/:
  - players_200.json (contoh output generator, 200 pemain)

## Catatan
- Skala atribut 1–20 (ala FM). Potential 40–200 menentukan rarity.
- Distribusi ras/elemen mengikuti nation & club seed.
- Synergy tags dipakai engine untuk combo & chemistry.

## Integrasi
- Import YAML/JSON sesuai schema.
- Untuk generate masif: gandakan fungsi `gen_player()` dengan seed berbeda.
- Ekspansi mudah: tambahkan pools nama, klub, nation — generator auto menyesuaikan.

